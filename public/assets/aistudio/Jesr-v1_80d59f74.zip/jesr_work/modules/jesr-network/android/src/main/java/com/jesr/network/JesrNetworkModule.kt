package com.jesr.network

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class JesrNetworkModule : Module() {
  private var router: MeshRouter? = null
  private var ble: BleMeshTransport? = null
  private var wifi: WifiDirectMeshTransport? = null
  private var active = false
  private var batteryMode = false
  private var networkKey: ByteArray? = null
  private val candidates = ConcurrentHashMap<String, MutableMap<String, Any?>>()
  private val linkRegistry = ConcurrentHashMap<String, MeshLink>()
  private val maintenanceHandler = Handler(Looper.getMainLooper())
  private val maintenance = object : Runnable {
    override fun run() {
      if (!active) return
      router?.tick()
      maintenanceHandler.postDelayed(this, 1_000L)
    }
  }

  override fun definition() = ModuleDefinition {
    Name("JesrNetwork")
    Events("onMeshState", "onMeshLog", "onPeerDiscovered", "onPingResult", "onDataReceived")

    OnCreate {
      ensureIdentity()
      ensureNetworkKey()
    }

    OnDestroy {
      stopInternal()
    }

    AsyncFunction("getSnapshot") {
      currentSnapshot()
    }

    AsyncFunction("getDiagnostics") {
      DiagnosticsStore.read(requireContext())
    }

    AsyncFunction("clearDiagnostics") {
      DiagnosticsStore.clear(requireContext())
      true
    }

    AsyncFunction("startNetwork") { mode: String ->
      val context = requireContext()
      requireRuntimePermissions(context)
      if (active) return@AsyncFunction currentSnapshot()
      batteryMode = mode == "battery"
      val id = ensureIdentity()
      router = MeshRouter(
        id,
        transmitter = { peerId, transport, payload ->
          when (transport) {
            MeshTransportKind.BLE -> ble?.send(peerId, payload) == true
            MeshTransportKind.WIFI_DIRECT -> wifi?.send(peerId, payload) == true
          }
        },
        eventSink = { event -> publishRouterEvent(event) }
      )
      maintenanceHandler.removeCallbacks(maintenance)
      maintenanceHandler.postDelayed(maintenance, 1_000L)
      try {
        val serviceIntent = Intent(context, MeshForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
        else context.startService(serviceIntent)
      } catch (error: Exception) {
        recordFailure("start.foreground_service", error)
        publishLog("foreground_service_unavailable", "تعذر تشغيل خدمة الشبكة الخلفية؛ سيستمر الاتصال في الواجهة إن أمكن")
      }
      active = true
      var started = false

      try {
        val bleTransport = BleMeshTransport(
          context = context,
          localId = id,
          onPeerReady = { peerId, quality, rssi ->
            candidates.remove(peerId)
            putLink(MeshLink(peerId, MeshTransportKind.BLE, quality, 0, null, 0.0, rssi, qualityMeasured = false))
            publishState()
          },
          onPeerLost = { peerId -> removeLink(peerId, MeshTransportKind.BLE); publishState() },
          onPacket = { peerId, packet -> router?.receive(packet, peerId, MeshTransportKind.BLE) },
          onLog = { kind, message -> publishLog(kind, message) }
        )
        ble = bleTransport
        bleTransport.start(batteryMode)
        started = true
      } catch (error: Exception) {
        recordFailure("start.ble", error)
        if (error.message?.contains("فعّل Bluetooth") == true) requestBluetoothEnable(context)
        publishLog("ble_unavailable", "تعذر بدء BLE (${error.javaClass.simpleName})")
      }

      try {
        val wifiTransport = WifiDirectMeshTransport(
          context = context,
          localId = id,
          onCandidate = { peerId ->
            if (!linkRegistry.values.any { it.peerId == peerId }) {
              candidates[peerId] = peerCandidate(peerId, "wifi-direct")
              candidates[peerId]?.let { sendEvent("onPeerDiscovered", it) }
              publishState()
            }
          },
          onLink = { peerId ->
            candidates.remove(peerId)
            // Wi‑Fi P2P has no RSSI measurement here; leave signal strength unavailable.
            putLink(MeshLink(peerId, MeshTransportKind.WIFI_DIRECT, 0, 0, null, 0.0, null))
            publishState()
          },
          onLost = { peerId -> removeLink(peerId, MeshTransportKind.WIFI_DIRECT); publishState() },
          onPacket = { peerId, packet -> router?.receive(packet, peerId, MeshTransportKind.WIFI_DIRECT) },
          onLog = { kind, message -> publishLog(kind, message) }
        )
        wifi = wifiTransport
        wifiTransport.start()
        started = true
      } catch (error: Exception) {
        recordFailure("start.wifi_direct", error)
        if (error.message?.contains("فعّل Wi‑Fi") == true) requestWifiEnable(context)
        publishLog("wifi_direct_unavailable", "تعذر بدء Wi‑Fi Direct (${error.javaClass.simpleName})")
      }

      if (!started) {
        stopInternal()
        throw IllegalStateException("لم يبدأ BLE أو Wi‑Fi Direct. افحص دعم الجهاز والصلاحيات وحالة Bluetooth وWi‑Fi.")
      }
      publishState()
      currentSnapshot()
    }

    AsyncFunction("stopNetwork") {
      stopInternal()
      currentSnapshot()
    }

    AsyncFunction("discoverPeers") {
      if (!active) throw IllegalStateException("ابدأ الشبكة أولًا")
      ble?.discoverNow()
      wifi?.discoverPeers()
      publishLog("discovery", "بدأ البحث المحلي عن الأجهزة القريبة")
    }

    AsyncFunction("connectPeer") { peerId: String ->
      if (!active) throw IllegalStateException("الشبكة متوقفة")
      val candidate = candidates[peerId]
      if (candidate?.get("transport") == "wifi-direct") wifi?.connect(peerId)
      else throw IllegalArgumentException("اتصال BLE يبدأ تلقائيًا عند اكتشاف إعلان الجهاز")
    }

    AsyncFunction("sendPing") { peerId: String ->
      if (!active) throw IllegalStateException("الشبكة متوقفة")
      router?.ping(peerId) ?: throw IllegalStateException("محرك الشبكة غير جاهز")
    }

    AsyncFunction("sendSecureData") { peerId: String, dataType: String, plaintext: String ->
      if (!active) throw IllegalStateException("الشبكة متوقفة")
      val key = ensureNetworkKey()
      require(dataType.matches(Regex("[a-z0-9_-]{1,32}"))) { "نوع البيانات غير صالح" }
      require(plaintext.toByteArray(Charsets.UTF_8).size <= MAX_SECURE_PAYLOAD_BYTES) { "البيانات أكبر من الحد المسموح" }
      val encrypted = encryptData(key, dataType, plaintext)
      router?.sendData(peerId, encrypted) ?: throw IllegalStateException("محرك الشبكة غير جاهز")
    }
  }

  private fun requireContext(): Context = requireNotNull(appContext.reactContext) { "سياق Android غير متاح" }

  private fun ensureIdentity(): String {
    val context = requireContext()
    val preferences = context.getSharedPreferences("jesr_local_identity", Context.MODE_PRIVATE)
    val current = preferences.getString("node_id", null)
    if (!current.isNullOrBlank()) return current
    val created = UUID.randomUUID().toString()
    preferences.edit().putString("node_id", created).apply()
    return created
  }

  private fun ensureNetworkKey(): ByteArray {
    val current = networkKey
    if (current != null) return current
    return deriveNetworkKey(INTERNAL_NETWORK_SEED).also { networkKey = it }
  }

  private fun requireRuntimePermissions(context: Context) {
    val required = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= 31) {
      required += Manifest.permission.BLUETOOTH_SCAN
      required += Manifest.permission.BLUETOOTH_ADVERTISE
      required += Manifest.permission.BLUETOOTH_CONNECT
    } else {
      required += Manifest.permission.ACCESS_FINE_LOCATION
    }
    if (Build.VERSION.SDK_INT >= 33) required += Manifest.permission.NEARBY_WIFI_DEVICES
    else required += Manifest.permission.ACCESS_FINE_LOCATION
    val missing = required.distinct().filter { context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    if (missing.isNotEmpty()) throw SecurityException("تحتاج الشبكة إلى موافقات Android التالية قبل التشغيل: ${missing.joinToString()}")
  }

  private fun requestBluetoothEnable(context: Context) {
    try {
      context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      publishLog("radio_action_required", "طلب Jesr من Android تفعيل Bluetooth")
    } catch (error: Exception) {
      publishLog("radio_action_failed", "تعذر فتح مطالبة Bluetooth (${error.javaClass.simpleName})")
    }
  }

  private fun requestWifiEnable(context: Context) {
    try {
      context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      publishLog("radio_action_required", "افتح Android إعدادات Wi-Fi لتفعيل Wi-Fi Direct")
    } catch (error: Exception) {
      publishLog("radio_action_failed", "تعذر فتح إعدادات Wi-Fi (${error.javaClass.simpleName})")
    }
  }

  private fun recordFailure(operation: String, error: Throwable, detail: String? = null) {
    appContext.reactContext?.let { DiagnosticsStore.record(it, operation, error, detail) }
  }

  private fun stopInternal() {
    active = false
    maintenanceHandler.removeCallbacks(maintenance)
    linkRegistry.clear()
    try { ble?.stop() } catch (_: Exception) { }
    try { wifi?.stop() } catch (_: Exception) { }
    router?.clearLinks()
    ble = null
    wifi = null
    candidates.clear()
    val context = appContext.reactContext
    if (context != null) {
      try { context.stopService(Intent(context, MeshForegroundService::class.java)) } catch (_: Exception) { }
    }
    publishState()
  }

  private fun currentSnapshot(): Map<String, Any?> {
    val context = appContext.reactContext
    val id = if (context != null) ensureIdentity() else "غير متاح"
    val routerState = router?.snapshot()
    val peers = (routerState?.get("peers") as? List<*>)?.toMutableList() ?: mutableListOf()
    peers.addAll(candidates.values)
    return mapOf(
      "available" to true,
      "active" to active,
      "localId" to id,
      "transportState" to if (!active) "stopped" else if (peers.any { (it as? Map<*, *>)?.get("connected") == true }) "connected" else "searching",
      "batteryMode" to if (batteryMode) "battery" else "balanced",
      "peers" to peers,
      "routes" to (routerState?.get("routes") ?: emptyList<Map<String, Any?>>()),
      "pendingPackets" to (routerState?.get("pendingPackets") ?: 0),
      "events" to (routerState?.get("events") ?: emptyList<Map<String, Any?>>())
    )
  }

  private fun peerCandidate(peerId: String, transport: String): MutableMap<String, Any?> = mutableMapOf(
    "id" to peerId,
    "transport" to transport,
    "direct" to false,
    "quality" to 0,
    "qualityMeasured" to false,
    "lossPercent" to 0,
    "lossMeasured" to false,
    "latencyMs" to null,
    "stability" to 0.0,
    "stabilityMeasured" to false,
    "lastSeenAt" to System.currentTimeMillis(),
    "connected" to false
  )

  private fun linkKey(peerId: String, transport: MeshTransportKind) = "$peerId|${transport.wireName}"

  private fun putLink(link: MeshLink) {
    if (!active) return
    linkRegistry[linkKey(link.peerId, link.transport)] = link
    val preferred = linkRegistry.values
      .filter { it.peerId == link.peerId }
      .maxByOrNull { if (it.transport == MeshTransportKind.WIFI_DIRECT) 2 else 1 }
    preferred?.let { router?.updateLink(it) }
  }

  private fun removeLink(peerId: String, transport: MeshTransportKind) {
    linkRegistry.remove(linkKey(peerId, transport))
    if (!active) return
    val fallback = linkRegistry.values
      .filter { it.peerId == peerId }
      .maxByOrNull { if (it.transport == MeshTransportKind.WIFI_DIRECT) 2 else 1 }
    if (fallback == null) router?.removeLink(peerId) else router?.updateLink(fallback)
  }

  private fun publishRouterEvent(event: Map<String, Any?>) {
    val published = if (event["kind"] == "data_received") {
      val copy = event.toMutableMap()
      val encoded = event["payload"] as? String
      val key = ensureNetworkKey()
      if (encoded != null) {
        try {
          val envelope = JSONObject(encoded)
          val decrypted = decryptData(key, envelope)
          copy.remove("payload")
          copy["dataType"] = decrypted.first
          copy["data"] = decrypted.second
          copy["encrypted"] = true
        } catch (_: Exception) {
          copy["kind"] = "data_decrypt_failed"
          copy["message"] = "تعذر فك حزمة البيانات؛ تحقق من مفتاح الشبكة"
        }
      } else {
        copy["kind"] = "data_decrypt_failed"
        copy["message"] = "تعذر تهيئة التشفير الداخلي للحزمة"
      }
      copy
    } else event
    sendEvent("onMeshLog", published)
    if (published["kind"] == "ping_ack" || published["kind"] == "routing_failed") {
      val result = published.toMutableMap()
      result["success"] = published["kind"] == "ping_ack"
      sendEvent("onPingResult", result)
    }
    if (published["kind"] == "data_received") sendEvent("onDataReceived", published)
    publishState()
  }

  private fun deriveNetworkKey(passphrase: String): ByteArray =
    MessageDigest.getInstance("SHA-256").digest(passphrase.toByteArray(Charsets.UTF_8))

  private fun encryptData(key: ByteArray, dataType: String, plaintext: String): JSONObject {
    val nonce = ByteArray(GCM_NONCE_BYTES)
    SecureRandom().nextBytes(nonce)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, nonce))
    cipher.updateAAD(dataType.toByteArray(Charsets.UTF_8))
    val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
    return JSONObject()
      .put("alg", "A256GCM")
      .put("type", dataType)
      .put("nonce", Base64.encodeToString(nonce, Base64.NO_WRAP))
      .put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
  }

  private fun decryptData(key: ByteArray, envelope: JSONObject): Pair<String, String> {
    require(envelope.optString("alg") == "A256GCM")
    val dataType = envelope.getString("type")
    val nonce = Base64.decode(envelope.getString("nonce"), Base64.DEFAULT)
    val ciphertext = Base64.decode(envelope.getString("ciphertext"), Base64.DEFAULT)
    require(nonce.size == GCM_NONCE_BYTES)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, nonce))
    cipher.updateAAD(dataType.toByteArray(Charsets.UTF_8))
    return dataType to String(cipher.doFinal(ciphertext), Charsets.UTF_8)
  }

  private companion object {
    // Hidden application-wide seed. Replace with authenticated device pairing in a future release.
    const val INTERNAL_NETWORK_SEED = "jesr-local-mesh-v1"
    const val GCM_NONCE_BYTES = 12
    const val GCM_TAG_BITS = 128
    const val MAX_SECURE_PAYLOAD_BYTES = 6 * 1024
  }

  private fun publishLog(kind: String, message: String) {
    try {
      sendEvent("onMeshLog", mapOf("id" to UUID.randomUUID().toString(), "at" to System.currentTimeMillis(), "kind" to kind, "message" to message))
    } catch (error: Exception) {
      recordFailure("event.onMeshLog", error, "kind=$kind message=$message")
    }
  }

  private fun publishState() {
    try {
      sendEvent("onMeshState", currentSnapshot())
    } catch (error: Exception) {
      recordFailure("event.onMeshState", error)
    }
  }
}
