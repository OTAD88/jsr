package com.jesr.network

import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object DiagnosticsStore {
  private const val FILE_NAME = "jesr-diagnostics.log"
  private const val MAX_BYTES = 128 * 1024

  @Synchronized
  fun record(context: Context, operation: String, error: Throwable, detail: String? = null) {
    val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date())
    val stack = StringWriter().also { writer -> error.printStackTrace(PrintWriter(writer)) }.toString()
    val entry = buildString {
      append("[$timestamp] operation=").append(operation).append('\n')
      append("exception=").append(error.javaClass.name).append('\n')
      append("message=").append(error.message ?: "").append('\n')
      if (!detail.isNullOrBlank()) append("detail=").append(detail).append('\n')
      append(stack).append('\n')
    }
    try {
      val file = context.getFileStreamPath(FILE_NAME)
      val previous = if (file.exists()) file.readText(Charsets.UTF_8) else ""
      val combined = (previous + entry).takeLast(MAX_BYTES)
      context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE).use { it.write(combined.toByteArray(Charsets.UTF_8)) }
    } catch (_: Exception) {
      // Diagnostics must never become a second crash path.
    }
  }

  @Synchronized
  fun read(context: Context): String = try {
    context.openFileInput(FILE_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() }
  } catch (_: Exception) {
    ""
  }

  @Synchronized
  fun clear(context: Context) {
    try { context.deleteFile(FILE_NAME) } catch (_: Exception) { }
  }
}
