import { describe, expect, it } from "vitest";
import { MeshRouter } from "../../lib/mesh/router";
import { createDefaultCustomScenario, runCustomScenario, validateCustomScenario } from "../../lib/mesh/simulation";

describe("custom scenario simulation", () => {
  it("runs a custom three-node scenario through MeshRouter", () => {
    const result = runCustomScenario(createDefaultCustomScenario());
    expect(result.delivered).toBe(true);
    expect(result.path).toEqual(["A", "B", "C"]);
    expect(result.events.some(({ event }) => event.kind === "ping_ack")).toBe(true);
  });

  it("reroutes after disabling the preferred link", () => {
    const scenario = createDefaultCustomScenario();
    scenario.nodes.push({ id: "D", enabled: true });
    scenario.links.push(
      { id: "A-D", from: "A", to: "D", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 15 },
      { id: "D-C", from: "D", to: "C", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 15 },
    );
    scenario.links.find((link) => link.id === "B-C")!.enabled = false;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(true);
    expect(result.path).toEqual(["A", "D", "C"]);
  });

  it("applies 100 percent packet loss and fails delivery", () => {
    const scenario = createDefaultCustomScenario();
    scenario.links[0].lossPercent = 100;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.droppedTransmissions).toBeGreaterThan(0);
  });

  it("applies link latency to simulated elapsed time", () => {
    const scenario = createDefaultCustomScenario();
    scenario.links.forEach((link) => { link.latencyMs = 75; });
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(true);
    expect(result.elapsedMs).toBeGreaterThanOrEqual(150);
  });

  it("uses measured quality in route scoring", () => {
    const router = new MeshRouter("A", { now: () => 1_000 });
    router.observeLink({ peerId: "weak", type: "ble", quality: 20, lossPercent: 0, latencyMs: 10, stability: 1, qualityMeasured: true, lossMeasured: true, stabilityMeasured: false, lastSeenAt: 1_000 });
    router.observeLink({ peerId: "strong", type: "ble", quality: 95, lossPercent: 0, latencyMs: 10, stability: 1, qualityMeasured: true, lossMeasured: true, stabilityMeasured: false, lastSeenAt: 1_000 });
    const routes = router.getSnapshot().routes;
    expect(routes[0].destinationId).toBe("strong");
    expect(routes[0].score).toBeLessThan(routes[1].score);
  });

  it("reports a failed run when TTL is too small", () => {
    const scenario = createDefaultCustomScenario();
    scenario.ttl = 1;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.events.some(({ event }) => event.kind === "routing_failed")).toBe(true);
  });

  it("accepts valid saved data and rejects duplicate or invalid links", () => {
    const valid = createDefaultCustomScenario();
    expect(validateCustomScenario(JSON.parse(JSON.stringify(valid)))).toBe(true);
    const duplicate = { ...valid, links: [...valid.links, { ...valid.links[0], id: "duplicate" }] };
    expect(validateCustomScenario(duplicate)).toBe(false);
    const invalid = { ...valid, links: [{ ...valid.links[0], from: "A", to: "A" }] };
    expect(validateCustomScenario(invalid)).toBe(false);
  });

  it("stores a packet and forwards it when a link returns", () => {
    const router = new MeshRouter("A", { now: () => 5_000, packetId: () => "queued" });
    expect(router.sendPing("B")).toEqual([]);
    expect(router.getSnapshot().pendingPackets).toBe(1);
    const flushed = router.observeLink({ peerId: "B", type: "ble", quality: 90, lossPercent: 0, latencyMs: 10, stability: 1, qualityMeasured: true, lossMeasured: true, stabilityMeasured: false, lastSeenAt: 5_000 });
    expect(flushed).toHaveLength(1);
    expect(flushed[0].peerId).toBe("B");
    expect(router.getSnapshot().pendingPackets).toBe(0);
  });
});
