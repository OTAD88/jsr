import { describe, expect, it } from "vitest";
import { MeshRouter } from "../../lib/mesh/router";
import { createDefaultCustomScenario, runCustomScenario, type CustomScenario } from "../../lib/mesh/simulation";

function lineScenario(): CustomScenario {
  const scenario = createDefaultCustomScenario();
  scenario.nodes = ["A", "B", "C", "D"].map((id) => ({ id, enabled: true }));
  scenario.links = [
    { id: "A-B", from: "A", to: "B", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "B-C", from: "B", to: "C", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "C-D", from: "C", to: "D", transport: "wifi-direct", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
  ];
  scenario.sourceId = "A";
  scenario.targetId = "D";
  return scenario;
}

function multiPathCycle(): CustomScenario {
  const scenario = lineScenario();
  scenario.links.push(
    { id: "A-C", from: "A", to: "C", transport: "wifi-direct", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "B-D", from: "B", to: "D", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "C-A", from: "C", to: "A", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
  );
  return scenario;
}

describe("Mesh Simulation closure evidence", () => {
  it("stores at B while B-C is down, then delivers once after recovery", () => {
    let now = 1_000;
    let sequence = 0;
    const packetId = () => `recover-${++sequence}`;
    const metrics = (peerId: string) => ({ peerId, type: "ble" as const, quality: 90, lossPercent: 0, latencyMs: 10, stability: 1, qualityMeasured: true, lossMeasured: true, stabilityMeasured: true, lastSeenAt: now });
    const a = new MeshRouter("A", { now: () => now, packetId });
    const b = new MeshRouter("B", { now: () => now, packetId });
    const c = new MeshRouter("C", { now: () => now, packetId });
    a.observeLink(metrics("B"));
    b.observeLink(metrics("A"));
    const toB = a.sendPing("C");
    expect(toB).toHaveLength(1);
    const storedAtB = b.receive(toB[0].packet, "A");
    expect(storedAtB).toEqual([]);
    expect(b.getSnapshot().pendingPackets).toBe(1);
    expect(b.getSnapshot().diagnostics.queueStored).toBe(1);

    c.observeLink(metrics("B"));
    const recovered = b.observeLink(metrics("C"));
    expect(recovered).toHaveLength(1);
    const toC = c.receive(recovered[0].packet, "B");
    expect(c.getSnapshot().diagnostics.pingDelivered).toBe(1);
    const toBForAck = toC.map((item) => ({ from: "C", to: item.peerId, packet: item.packet }));
    const toA = toBForAck.flatMap((frame) => b.receive(frame.packet, frame.from));
    for (const transmission of toA) a.receive(transmission.packet, "B");
    expect(a.getSnapshot().diagnostics.ackDelivered).toBe(1);
    expect(a.getSnapshot().events.filter((event) => event.kind === "ping_ack")).toHaveLength(1);
    expect(c.getSnapshot().diagnostics.delivered).toBe(1);
  });

  it("delivers once in a cyclic multi-path network and reports duplicate rejection", () => {
    const result = runCustomScenario(multiPathCycle());
    const target = result.diagnostics.D;
    expect(result.delivered).toBe(true);
    expect(target.pingDelivered).toBe(1);
    expect(target.delivered).toBe(1);
    expect(target.duplicateRejected).toBeGreaterThanOrEqual(1);
    expect(result.path.length - 1).toBe(result.hops);
  });

  it("allows delivery on the final TTL hop and reports initial/final TTL", () => {
    const scenario = lineScenario();
    scenario.ttl = 3;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(true);
    expect(result.initialTtl).toBe(3);
    expect(result.finalTtl).toBe(0);
    expect(result.hops).toBe(3);
  });

  it("rejects an insufficient TTL without allowing a negative value", () => {
    const scenario = lineScenario();
    scenario.ttl = 2;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.finalTtl).toBeNull();
    expect(Object.values(result.diagnostics).some((item) => item.ttlRejected > 0)).toBe(true);
    expect(result.events.filter(({ event }) => event.kind === "routing_failed").every(({ event }) => (event.ttl ?? 0) >= 0)).toBe(true);
  });

  it("rejects TTL zero before a hop and does not deliver", () => {
    const scenario = lineScenario();
    scenario.ttl = 0;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(Object.values(result.diagnostics).some((item) => item.ttlRejected > 0)).toBe(true);
  });

  it("terminates a limited-TTL ring without delivery or unbounded forwarding", () => {
    const scenario = multiPathCycle();
    scenario.targetId = "E";
    scenario.nodes.push({ id: "E", enabled: true });
    scenario.ttl = 2;
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.steps).toBeLessThan(512);
    expect(Object.values(result.diagnostics).some((item) => item.duplicateRejected > 0 || item.ttlRejected > 0)).toBe(true);
  });

  it("distinguishes Ping delivery, ACK delivery, and ACK arrival at source", () => {
    const result = runCustomScenario(lineScenario());
    expect(result.diagnostics.D.pingDelivered).toBe(1);
    expect(result.diagnostics.A.ackDelivered).toBe(1);
    expect(result.events.filter(({ event }) => event.kind === "ping_ack")).toHaveLength(1);
    expect(result.events.filter(({ event }) => event.kind === "packet_delivered" && event.nodeId === "D")).toHaveLength(1);
  });

  it("does not claim success when the destination has no route", () => {
    const scenario = lineScenario();
    scenario.nodes.push({ id: "E", enabled: true });
    scenario.targetId = "E";
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.path).toEqual([]);
  });

  it("stores, forwards, and delivers one queued packet after link recovery", () => {
    let now = 1_000;
    const source = new MeshRouter("A", { now: () => now, packetId: () => "store-1" });
    const first = source.sendPing("B");
    expect(first).toEqual([]);
    expect(source.getSnapshot().pendingPackets).toBe(1);
    expect(source.getSnapshot().diagnostics.queueStored).toBe(1);
    const flushed = source.observeLink({ peerId: "B", type: "ble", quality: 90, lossPercent: 0, latencyMs: 10, stability: 1, qualityMeasured: true, lossMeasured: true, stabilityMeasured: true, lastSeenAt: now });
    expect(flushed).toHaveLength(1);
    expect(source.getSnapshot().pendingPackets).toBe(0);
    now += 10;
    expect(source.getSnapshot().diagnostics.queueExpired).toBe(0);
  });
});
