import { describe, expect, it } from "vitest";
import { decideConnectionStart, shouldRetry } from "../../lib/mesh/connection-safety";

describe("connection safety policy", () => {
  it("requests permissions before starting", () => {
    expect(decideConnectionStart({ bluetooth: "enabled", wifi: "enabled", bluetoothPermission: false, wifiPermission: true })).toEqual({ action: "request-permission" });
  });

  it("requests Bluetooth when both radios are disabled", () => {
    expect(decideConnectionStart({ bluetooth: "disabled", wifi: "disabled", bluetoothPermission: true, wifiPermission: true })).toEqual({ action: "request-radio", radio: "bluetooth" });
  });

  it("can continue with Wi-Fi when Bluetooth is unavailable", () => {
    expect(decideConnectionStart({ bluetooth: "unsupported", wifi: "enabled", bluetoothPermission: true, wifiPermission: true })).toEqual({ action: "start" });
  });

  it("reports no-radio instead of retrying forever", () => {
    expect(decideConnectionStart({ bluetooth: "unsupported", wifi: "unsupported", bluetoothPermission: true, wifiPermission: true })).toEqual({ action: "unavailable", reason: "no-radio" });
  });

  it("retries BUSY only within a bounded limit", () => {
    expect(shouldRetry("busy", 0)).toBe(true);
    expect(shouldRetry("busy", 2)).toBe(true);
    expect(shouldRetry("busy", 3)).toBe(false);
    expect(shouldRetry("permission", 0)).toBe(false);
    expect(shouldRetry("error", 0)).toBe(false);
  });
});
