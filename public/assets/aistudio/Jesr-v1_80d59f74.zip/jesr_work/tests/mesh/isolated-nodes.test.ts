import { describe, expect, it } from "vitest";
import { createDefaultCustomScenario, runCustomScenario, type CustomScenario } from "../../lib/mesh/simulation";

function diamond(): CustomScenario {
  const scenario = createDefaultCustomScenario();
  scenario.nodes = ["A", "B", "C", "D"].map((id) => ({ id, enabled: true }));
  scenario.links = [
    { id: "A-B", from: "A", to: "B", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "B-D", from: "B", to: "D", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "A-C", from: "A", to: "C", transport: "wifi-direct", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
    { id: "C-D", from: "C", to: "D", transport: "wifi-direct", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 },
  ];
  scenario.sourceId = "A";
  scenario.targetId = "D";
  return scenario;
}

function summary(scenario: CustomScenario) {
  const result = runCustomScenario(scenario);
  return { delivered: result.delivered, path: result.path, hops: result.hops, transmissions: result.transmissions };
}

describe("isolated node regression", () => {
  it("keeps the four-node diamond result unchanged after adding isolated E", () => {
    const scenario = diamond();
    const baseline = summary(scenario);
    scenario.nodes.push({ id: "E", enabled: true });
    expect(summary(scenario)).toEqual(baseline);
  });

  it("keeps the result unchanged after adding isolated F as well", () => {
    const scenario = diamond();
    const baseline = summary(scenario);
    scenario.nodes.push({ id: "E", enabled: true }, { id: "F", enabled: true });
    expect(summary(scenario)).toEqual(baseline);
  });

  it("keeps A-D unaffected when isolated E-F are linked only to each other", () => {
    const scenario = diamond();
    const baseline = summary(scenario);
    scenario.nodes.push({ id: "E", enabled: true }, { id: "F", enabled: true });
    scenario.links.push({ id: "E-F", from: "E", to: "F", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 });
    expect(summary(scenario)).toEqual(baseline);
  });

  it("returns to the original result after removing E", () => {
    const scenario = diamond();
    const baseline = summary(scenario);
    scenario.nodes.push({ id: "E", enabled: true }, { id: "F", enabled: true });
    scenario.links.push({ id: "E-F", from: "E", to: "F", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 10 });
    scenario.nodes = scenario.nodes.filter((node) => node.id !== "E");
    scenario.links = scenario.links.filter((link) => link.from !== "E" && link.to !== "E");
    expect(summary(scenario)).toEqual(baseline);
  });

  it("does not silently collapse duplicate node IDs", () => {
    const scenario = diamond();
    scenario.nodes.push({ id: "B", enabled: true });
    const result = runCustomScenario(scenario);
    expect(result.delivered).toBe(false);
    expect(result.error).toContain("فريدة");
  });
});
