import { describe, expect, it } from "vitest";
import { createDefaultCustomScenario } from "../../lib/mesh/simulation";
import { createLinkFromSelection, parseCustomTtlDraft, removeNodeById } from "../../lib/mesh/custom-builder";

describe("Custom Scenario Builder interaction logic", () => {
  it("keeps a typed TTL of 3 as 3", () => {
    expect(parseCustomTtlDraft("3")).toBe(3);
  });

  it("does not append after clearing TTL: empty then 5 becomes 5", () => {
    expect(parseCustomTtlDraft("")).toBeNull();
    expect(parseCustomTtlDraft("5")).toBe(5);
  });

  it("changes 32 to 3 without retaining the old 2", () => {
    expect(parseCustomTtlDraft("32")).toBe(32);
    expect(parseCustomTtlDraft("3")).toBe(3);
  });

  it("creates exactly the selected B-D link", () => {
    const scenario = createDefaultCustomScenario();
    scenario.nodes.push({ id: "D", enabled: true });
    const link = createLinkFromSelection(scenario, "B", "D");
    expect(link?.from).toBe("B");
    expect(link?.to).toBe("D");
    expect(link?.id).toBe("B-D");
  });

  it("creates exactly the selected A-C link", () => {
    const scenario = createDefaultCustomScenario();
    const link = createLinkFromSelection(scenario, "A", "C");
    expect(link?.from).toBe("A");
    expect(link?.to).toBe("C");
    expect(link?.id).toBe("A-C");
  });

  it("preserves other node IDs when a node is added or removed", () => {
    const scenario = createDefaultCustomScenario();
    scenario.nodes.push({ id: "D", enabled: true });
    const afterDelete = removeNodeById(scenario, "C");
    expect(afterDelete.nodes.map((node) => node.id)).toEqual(["A", "B", "D"]);
    expect(afterDelete.nodes.map((node) => node.id)).not.toContain("C");
    expect(afterDelete.links.every((link) => link.from !== "C" && link.to !== "C")).toBe(true);
  });

  it("does not create a link without two distinct selected endpoints", () => {
    const scenario = createDefaultCustomScenario();
    expect(createLinkFromSelection(scenario, null, null)).toBeNull();
    expect(createLinkFromSelection(scenario, "B", null)).toBeNull();
    expect(createLinkFromSelection(scenario, "B", "B")).toBeNull();
    expect(createLinkFromSelection(scenario, "A", "B")).toBeNull();
  });
});
