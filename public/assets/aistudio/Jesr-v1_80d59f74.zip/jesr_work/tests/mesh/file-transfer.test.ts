import { describe, expect, it } from "vitest";
import { assembleBase64File, splitBase64File } from "../../lib/mesh/file-transfer";

describe("file transfer framing", () => {
  it("splits and reassembles the exact base64 payload", () => {
    const base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const chunks = splitBase64File("file-1", "note.txt", "text/plain", base64, 5);
    expect(chunks.map((chunk) => chunk.index)).toEqual([0, 1, 2, 3, 4, 5]);
    expect(assembleBase64File([...chunks].reverse())?.base64).toBe(base64);
  });

  it("does not complete while a chunk is missing", () => {
    const chunks = splitBase64File("file-2", "photo.bin", "application/octet-stream", "123456789", 3);
    expect(assembleBase64File(chunks.slice(0, -1))).toBeNull();
  });

  it("ignores duplicate indexes without corrupting the file", () => {
    const chunks = splitBase64File("file-3", "data.bin", "application/octet-stream", "123456789", 3);
    const result = assembleBase64File([chunks[0], chunks[0], chunks[2], chunks[1]]);
    expect(result?.base64).toBe("123456789");
  });

  it("rejects chunks from different files", () => {
    const first = splitBase64File("file-a", "a.txt", "text/plain", "abc", 2);
    const second = splitBase64File("file-b", "b.txt", "text/plain", "xyz", 2);
    expect(() => assembleBase64File([first[0], second[0]])).toThrow();
  });
});
