import { MeshRouter, type LinkType, type MeshEvent, type MeshPacket, type RouterDiagnostics, type Transmission } from "./router";

export interface SimulationNode { id: string; enabled: boolean; }
export interface SimulationLink {
  id: string;
  from: string;
  to: string;
  transport: LinkType;
  enabled: boolean;
  quality: number;
  lossPercent: number;
  latencyMs: number | null;
}
export interface CustomScenario {
  id: string;
  name: string;
  nodes: SimulationNode[];
  links: SimulationLink[];
  sourceId: string;
  targetId: string;
  ttl: number;
  packetLifetimeMs: number;
}
export interface SimulationRun {
  delivered: boolean;
  path: string[];
  hops: number;
  events: Array<{ nodeId: string; event: MeshEvent }>;
  transmissions: number;
  droppedTransmissions: number;
  steps: number;
  elapsedMs: number;
  initialTtl: number;
  finalTtl: number | null;
  dropReason?: string;
  diagnostics: Record<string, RouterDiagnostics>;
  error?: string;
}

function pairKey(a: string, b: string) { return a < b ? `${a}-${b}` : `${b}-${a}`; }

function shouldDrop(link: SimulationLink, packetId: string, attempt: number): boolean {
  if (link.lossPercent >= 100) return true;
  if (link.lossPercent <= 0) return false;
  let hash = attempt + packetId.length * 31 + link.id.length * 17;
  for (const character of `${packetId}:${link.id}`) hash = (hash * 33 + character.charCodeAt(0)) % 10_000;
  return hash % 100 < link.lossPercent;
}

function addLink(router: MeshRouter, link: SimulationLink, peerId: string, now: number) {
  router.observeLink({
    peerId,
    type: link.transport,
    quality: link.quality,
    lossPercent: link.lossPercent,
    latencyMs: link.latencyMs,
    stability: 1,
    qualityMeasured: true,
    lossMeasured: true,
    stabilityMeasured: false,
    lastSeenAt: now,
  });
}

export function runCustomScenario(scenario: CustomScenario): SimulationRun {
  const activeNodes = scenario.nodes.filter((node) => node.enabled).map((node) => node.id);
  if (new Set(activeNodes).size !== activeNodes.length) {
    return { delivered: false, path: [], hops: 0, events: [], transmissions: 0, droppedTransmissions: 0, steps: 0, elapsedMs: 0, initialTtl: scenario.ttl, finalTtl: null, diagnostics: {}, error: "معرفات العقد النشطة يجب أن تكون فريدة" };
  }
  if (!activeNodes.includes(scenario.sourceId) || !activeNodes.includes(scenario.targetId)) {
    return { delivered: false, path: [], hops: 0, events: [], transmissions: 0, droppedTransmissions: 0, steps: 0, elapsedMs: 0, initialTtl: scenario.ttl, finalTtl: null, diagnostics: {}, error: "المصدر والوجهة يجب أن تكونا عقدتين نشطتين" };
  }
  if (scenario.sourceId === scenario.targetId) {
    return { delivered: false, path: [], hops: 0, events: [], transmissions: 0, droppedTransmissions: 0, steps: 0, elapsedMs: 0, initialTtl: scenario.ttl, finalTtl: null, diagnostics: {}, error: "المصدر والوجهة يجب أن تكونا مختلفتين" };
  }

  let now = 1_000;
  let sequence = 0;
  const routers = new Map(activeNodes.map((id) => [id, new MeshRouter(id, {
    now: () => now,
    packetId: () => `custom-${++sequence}`,
    ttl: scenario.ttl,
    packetLifetimeMs: scenario.packetLifetimeMs,
  })]));
  const active = new Set(activeNodes);
  for (const link of scenario.links.filter((item) => item.enabled && active.has(item.from) && active.has(item.to))) {
    const from = routers.get(link.from)!;
    const to = routers.get(link.to)!;
    addLink(from, link, link.to, now);
    addLink(to, link, link.from, now);
  }

  const activeLinks = new Map(scenario.links.filter((link) => link.enabled && active.has(link.from) && active.has(link.to)).map((link) => [pairKey(link.from, link.to), link]));
  const queue: Array<{ from: string; to: string; packet: MeshPacket; deliverAt: number }> = [];
  let droppedTransmissions = 0;
  let enqueueAttempt = 0;
  const enqueue = (from: string, transmissions: Transmission[]) => {
    for (const transmission of transmissions) {
      const link = activeLinks.get(pairKey(from, transmission.peerId));
      if (!link || !routers.has(transmission.peerId)) continue;
      enqueueAttempt += 1;
      if (shouldDrop(link, transmission.packet.id, enqueueAttempt)) { droppedTransmissions += 1; continue; }
      queue.push({ from, to: transmission.peerId, packet: transmission.packet, deliverAt: now + Math.max(0, link.latencyMs ?? 0) });
    }
  };
  const source = routers.get(scenario.sourceId)!;
  enqueue(scenario.sourceId, source.sendPing(scenario.targetId));

  let steps = 0;
  let transmissions = queue.length;
  while (queue.length && steps < 512) {
    queue.sort((a, b) => a.deliverAt - b.deliverAt);
    const frame = queue.shift()!;
    now = Math.max(now, frame.deliverAt);
    const router = routers.get(frame.to)!;
    const outgoing = router.receive(frame.packet, frame.from);
    transmissions += outgoing.length;
    enqueue(frame.to, outgoing);
    steps += 1;
  }

  const events: Array<{ nodeId: string; event: MeshEvent }> = [];
  const diagnostics: Record<string, RouterDiagnostics> = {};
  for (const [nodeId, router] of routers) {
    const snapshot = router.getSnapshot();
    diagnostics[nodeId] = snapshot.diagnostics;
    for (const event of snapshot.events) events.push({ nodeId, event });
  }
  events.sort((a, b) => a.event.at - b.event.at);
  const ack = routers.get(scenario.sourceId)!.getSnapshot().events.find((event) => event.kind === "ping_ack");
  const deliveredEvent = routers.get(scenario.targetId)!.getSnapshot().events.find((event) => event.kind === "packet_delivered");
  const failureEvent = events.find(({ event }) => event.kind === "routing_failed");
  return {
    delivered: Boolean(ack && deliveredEvent),
    path: ack?.path ?? deliveredEvent?.path ?? [],
    hops: (ack?.path ?? deliveredEvent?.path ?? []).length > 0 ? (ack?.path ?? deliveredEvent?.path ?? []).length - 1 : 0,
    events,
    transmissions,
    droppedTransmissions,
    steps,
    elapsedMs: now - 1_000,
    initialTtl: scenario.ttl,
    finalTtl: deliveredEvent?.ttl ?? null,
    dropReason: failureEvent?.event.message,
    diagnostics,
    error: steps >= 512 ? "تجاوزت المحاكاة حد الخطوات" : undefined,
  };
}

export function createDefaultCustomScenario(): CustomScenario {
  return {
    id: "custom-1",
    name: "سيناريو مخصص جديد",
    nodes: ["A", "B", "C"].map((id) => ({ id, enabled: true })),
    links: [
      { id: "A-B", from: "A", to: "B", transport: "ble", enabled: true, quality: 90, lossPercent: 0, latencyMs: 15 },
      { id: "B-C", from: "B", to: "C", transport: "wifi-direct", enabled: true, quality: 90, lossPercent: 0, latencyMs: 15 },
    ],
    sourceId: "A",
    targetId: "C",
    ttl: 8,
    packetLifetimeMs: 120_000,
  };
}

export function validateCustomScenario(value: unknown): value is CustomScenario {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<CustomScenario>;
  if (typeof candidate.name !== "string" || !Array.isArray(candidate.nodes) || !Array.isArray(candidate.links)) return false;
  if (!candidate.nodes.every((node) => Boolean(node && typeof node === "object" && typeof (node as { id?: unknown }).id === "string" && typeof (node as { enabled?: unknown }).enabled === "boolean"))) return false;
  const nodeIds = new Set(candidate.nodes.map((node) => String((node as { id: string }).id)));
  if (nodeIds.size < 2 || nodeIds.has("")) return false;
  if (typeof candidate.sourceId !== "string" || typeof candidate.targetId !== "string" || candidate.sourceId === candidate.targetId || !nodeIds.has(candidate.sourceId) || !nodeIds.has(candidate.targetId)) return false;
  if (!candidate.nodes.find((node) => node.id === candidate.sourceId)?.enabled || !candidate.nodes.find((node) => node.id === candidate.targetId)?.enabled) return false;
  if (!Number.isInteger(candidate.ttl) || candidate.ttl! < 1 || candidate.ttl! > 32) return false;
  const pairs = new Set<string>();
  return candidate.links.every((link) => {
    if (!link || !nodeIds.has(link.from) || !nodeIds.has(link.to) || link.from === link.to || (link.transport !== "ble" && link.transport !== "wifi-direct") || !Number.isFinite(link.quality) || link.quality < 0 || link.quality > 100 || !Number.isFinite(link.lossPercent) || link.lossPercent < 0 || link.lossPercent > 100 || (link.latencyMs !== null && (!Number.isFinite(link.latencyMs) || link.latencyMs < 0))) return false;
    const pair = pairKey(link.from, link.to);
    if (pairs.has(pair)) return false;
    pairs.add(pair);
    return true;
  });
}
