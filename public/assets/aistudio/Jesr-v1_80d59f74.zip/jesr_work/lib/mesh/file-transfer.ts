export const FILE_CHUNK_CHARS = 3800;
export const MAX_FILE_BYTES = 2 * 1024 * 1024;

export type FileChunk = {
  fileId: string;
  index: number;
  total: number;
  name: string;
  mimeType: string;
  chunk: string;
};

export type FileManifest = Pick<FileChunk, "fileId" | "name" | "mimeType" | "total">;

export function splitBase64File(
  fileId: string,
  name: string,
  mimeType: string,
  base64: string,
  chunkChars = FILE_CHUNK_CHARS,
): FileChunk[] {
  if (!fileId || !name || !mimeType || !base64) throw new Error("بيانات الملف غير مكتملة");
  if (!Number.isInteger(chunkChars) || chunkChars < 1) throw new Error("حجم الجزء غير صالح");
  const total = Math.ceil(base64.length / chunkChars);
  return Array.from({ length: total }, (_, index) => ({
    fileId,
    index,
    total,
    name,
    mimeType,
    chunk: base64.slice(index * chunkChars, (index + 1) * chunkChars),
  }));
}

export function assembleBase64File(chunks: FileChunk[]): { manifest: FileManifest; base64: string } | null {
  if (chunks.length === 0) return null;
  const first = chunks[0];
  const valid = chunks.every((chunk) =>
    chunk.fileId === first.fileId &&
    chunk.name === first.name &&
    chunk.mimeType === first.mimeType &&
    chunk.total === first.total &&
    chunk.index >= 0 &&
    chunk.index < first.total,
  );
  if (!valid) throw new Error("أجزاء الملف لا تنتمي إلى نفس الملف");
  const byIndex = new Map(chunks.map((chunk) => [chunk.index, chunk]));
  if (byIndex.size !== first.total) return null;
  const ordered = Array.from({ length: first.total }, (_, index) => byIndex.get(index));
  if (ordered.some((chunk) => !chunk)) return null;
  return {
    manifest: { fileId: first.fileId, name: first.name, mimeType: first.mimeType, total: first.total },
    base64: ordered.map((chunk) => chunk!.chunk).join(""),
  };
}
