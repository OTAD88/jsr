export type RadioState = "enabled" | "disabled" | "unsupported" | "permission-denied";

export type ConnectionDecision =
  | { action: "start" }
  | { action: "request-permission" }
  | { action: "request-radio"; radio: "bluetooth" | "wifi" }
  | { action: "unavailable"; reason: string };

export function decideConnectionStart(input: {
  bluetooth: RadioState;
  wifi: RadioState;
  bluetoothPermission: boolean;
  wifiPermission: boolean;
}): ConnectionDecision {
  if (!input.bluetoothPermission || !input.wifiPermission) return { action: "request-permission" };
  if (input.bluetooth === "unsupported" && input.wifi === "unsupported") {
    return { action: "unavailable", reason: "no-radio" };
  }
  if (input.bluetooth === "disabled" && input.wifi === "disabled") {
    return { action: "request-radio", radio: "bluetooth" };
  }
  if (input.bluetooth === "disabled" && input.wifi === "unsupported") {
    return { action: "request-radio", radio: "bluetooth" };
  }
  if (input.wifi === "disabled" && input.bluetooth === "unsupported") {
    return { action: "request-radio", radio: "wifi" };
  }
  return { action: "start" };
}

export function shouldRetry(reason: "busy" | "error" | "permission" | "unsupported", attempt: number, maxAttempts = 3) {
  return reason === "busy" && attempt < maxAttempts;
}
