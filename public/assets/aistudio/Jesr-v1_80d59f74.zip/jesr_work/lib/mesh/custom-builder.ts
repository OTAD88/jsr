import type { CustomScenario, SimulationLink } from "./simulation";

export const MIN_CUSTOM_TTL = 1;
export const MAX_CUSTOM_TTL = 32;

/** Keeps the TextInput draft as text; conversion happens only on commit/run. */
export function parseCustomTtlDraft(draft: string): number | null {
  if (draft.trim() === "" || !/^\d+$/.test(draft)) return null;
  const value = Number(draft);
  return Number.isInteger(value) && value >= MIN_CUSTOM_TTL && value <= MAX_CUSTOM_TTL ? value : null;
}

export function createLinkFromSelection(scenario: CustomScenario, fromId: string | null, toId: string | null): SimulationLink | null {
  if (!fromId || !toId || fromId === toId) return null;
  const nodeIds = new Set(scenario.nodes.map((node) => node.id));
  if (!nodeIds.has(fromId) || !nodeIds.has(toId)) return null;
  const duplicate = scenario.links.some((link) => (link.from === fromId && link.to === toId) || (link.from === toId && link.to === fromId));
  if (duplicate) return null;
  return {
    id: `${fromId}-${toId}`,
    from: fromId,
    to: toId,
    transport: "ble",
    enabled: true,
    quality: 90,
    lossPercent: 0,
    latencyMs: 15,
  };
}

export function removeNodeById(scenario: CustomScenario, nodeId: string): CustomScenario {
  const nodes = scenario.nodes.filter((node) => node.id !== nodeId);
  const fallbackSource = scenario.sourceId === nodeId ? nodes[0]?.id ?? "" : scenario.sourceId;
  const fallbackTarget = scenario.targetId === nodeId ? nodes.find((node) => node.id !== fallbackSource)?.id ?? "" : scenario.targetId;
  return {
    ...scenario,
    nodes,
    links: scenario.links.filter((link) => link.from !== nodeId && link.to !== nodeId),
    sourceId: fallbackSource,
    targetId: fallbackTarget,
  };
}
