import AsyncStorage from "@react-native-async-storage/async-storage";

const CHAT_STORE_KEY = "jesr.chat.store.v2";
const LEGACY_FRIENDS_KEY = "jesr.friends.v1";
const LEGACY_PROFILE_KEY = "jesr.profile.v1";

export type FriendStatus = "pending" | "accepted";
export type Friend = {
  id: string;
  name: string;
  addedAt: number;
  status: FriendStatus;
  requestDirection?: "outgoing" | "incoming";
};

export type FriendRequest = { id: string; name: string; at: number };
export type PendingControlType = "friend_request" | "friend_accept" | "friend_reject";
export type PendingControl = {
  id: string;
  peerId: string;
  type: PendingControlType;
  payload: string;
  packetId?: string;
};

export type MessageDirection = "incoming" | "outgoing";
export type MessageStatus = "queued" | "sending" | "delivered" | "failed";
export type ChatMessage = {
  id: string;
  packetId?: string;
  peerId: string;
  text: string;
  at: number;
  direction: MessageDirection;
  status: MessageStatus;
};

export type ChatStore = {
  displayName: string;
  friends: Friend[];
  requests: FriendRequest[];
  pendingControls: PendingControl[];
  messages: ChatMessage[];
};

const EMPTY_STORE: ChatStore = {
  displayName: "مستخدم جسر",
  friends: [],
  requests: [],
  pendingControls: [],
  messages: [],
};
let mutationQueue: Promise<unknown> = Promise.resolve();

function normalizeStore(value: unknown): ChatStore {
  if (!value || typeof value !== "object") return { ...EMPTY_STORE };
  const record = value as Partial<ChatStore>;
  const friends: Friend[] = Array.isArray(record.friends)
    ? record.friends.filter((item) => Boolean(item && typeof item.id === "string" && typeof item.name === "string"))
      .map((item) => ({
        id: item.id,
        name: item.name,
        addedAt: typeof item.addedAt === "number" ? item.addedAt : Date.now(),
        status: item.status === "pending" ? "pending" : "accepted",
        requestDirection: item.requestDirection === "outgoing" || item.requestDirection === "incoming" ? item.requestDirection : undefined,
      }))
    : [];
  const requests: FriendRequest[] = Array.isArray(record.requests)
    ? record.requests.filter((item) => Boolean(item && typeof item.id === "string" && typeof item.name === "string"))
      .map((item) => ({ id: item.id, name: item.name, at: typeof item.at === "number" ? item.at : Date.now() }))
    : [];
  const pendingControls: PendingControl[] = Array.isArray(record.pendingControls)
    ? record.pendingControls.filter((item) => Boolean(
        item && typeof item.id === "string" && typeof item.peerId === "string" &&
        (item.type === "friend_request" || item.type === "friend_accept" || item.type === "friend_reject") &&
        typeof item.payload === "string"
      )).map((item) => ({ ...item }))
    : [];
  const messages: ChatMessage[] = Array.isArray(record.messages)
    ? record.messages.filter((item): item is ChatMessage => Boolean(
        item && typeof item.id === "string" && typeof item.peerId === "string" &&
        typeof item.text === "string" && typeof item.at === "number" &&
        (item.direction === "incoming" || item.direction === "outgoing")
      )).map((item) => ({
        ...item,
        status: (item.status === "delivered" || item.status === "failed" || item.status === "sending" ? item.status : "queued") as MessageStatus,
      }))
    : [];
  return {
    displayName: typeof record.displayName === "string" && record.displayName.trim() ? record.displayName : EMPTY_STORE.displayName,
    friends,
    requests,
    pendingControls,
    messages: messages.slice(-5000),
  };
}

export async function loadChatStore(): Promise<ChatStore> {
  try {
    const raw = await AsyncStorage.getItem(CHAT_STORE_KEY);
    if (raw) return normalizeStore(JSON.parse(raw));

    // Migrate contacts/profile from the previous combined chat screen without deleting legacy data.
    const [legacyFriends, legacyProfile] = await Promise.all([
      AsyncStorage.getItem(LEGACY_FRIENDS_KEY),
      AsyncStorage.getItem(LEGACY_PROFILE_KEY),
    ]);
    if (legacyFriends || legacyProfile) {
      let friends: Friend[] = [];
      try {
        const parsed = legacyFriends ? JSON.parse(legacyFriends) : [];
        if (Array.isArray(parsed)) friends = parsed
          .filter((item) => item && typeof item.id === "string")
          .map((item, index) => ({ id: item.id, name: typeof item.name === "string" ? item.name : "صديق جديد", addedAt: Date.now() - index, status: "accepted" as const }));
      } catch { friends = []; }
      const migrated = normalizeStore({ ...EMPTY_STORE, displayName: legacyProfile || EMPTY_STORE.displayName, friends });
      await AsyncStorage.setItem(CHAT_STORE_KEY, JSON.stringify(migrated));
      return migrated;
    }
    return { ...EMPTY_STORE };
  } catch {
    return { ...EMPTY_STORE };
  }
}

export async function saveChatStore(store: ChatStore): Promise<void> {
  await AsyncStorage.setItem(CHAT_STORE_KEY, JSON.stringify(normalizeStore(store)));
}

/** Serialize read-modify-write operations so simultaneous network events do not overwrite each other. */
export function updateChatStore(mutator: (current: ChatStore) => ChatStore): Promise<ChatStore> {
  const task = mutationQueue.then(async () => {
    const current = await loadChatStore();
    const next = normalizeStore(mutator(current));
    await saveChatStore(next);
    return next;
  });
  mutationQueue = task.then(() => undefined, () => undefined);
  return task;
}

export function makeLocalMessageId(): string {
  return `msg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
}

export function makeControlId(): string {
  return `ctl-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
}

export function upsertFriend(friends: Friend[], id: string, name: string, status: FriendStatus = "accepted", requestDirection?: Friend["requestDirection"]): Friend[] {
  const cleanId = id.trim();
  const cleanName = name.trim() || "جهة اتصال";
  const existing = friends.find((friend) => friend.id === cleanId);
  if (existing) return friends.map((friend) => friend.id === cleanId ? {
    ...friend,
    name: cleanName,
    status: status === "accepted" ? "accepted" : existing.status,
    requestDirection: status === "accepted" ? undefined : requestDirection ?? existing.requestDirection,
  } : friend);
  return [...friends, { id: cleanId, name: cleanName, addedAt: Date.now(), status, requestDirection }];
}

export function upsertRequest(requests: FriendRequest[], request: FriendRequest): FriendRequest[] {
  const current = requests.find((item) => item.id === request.id);
  if (current) return requests.map((item) => item.id === request.id ? { ...item, name: request.name || item.name } : item);
  return [...requests, request];
}

export function upsertMessage(messages: ChatMessage[], message: ChatMessage): ChatMessage[] {
  const existingIndex = messages.findIndex((item) => item.id === message.id && item.peerId === message.peerId);
  if (existingIndex < 0) return [...messages, message].sort((a, b) => a.at - b.at).slice(-5000);
  const next = messages.slice();
  next[existingIndex] = { ...next[existingIndex], ...message };
  return next.sort((a, b) => a.at - b.at);
}
