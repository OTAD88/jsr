# Jesr 1.6 — implementation review

## Changes in this source revision

- Replaced the previous combined technical workspace screen with a chat-first home screen and a dedicated conversation route.
- Applied a dark cinematic visual system using `#75AE9D` as the primary accent, deep green/charcoal surfaces, subtle ambient motion, pressed-state feedback, and Arabic-first RTL layouts.
- Hidden the simulation, transport diagnostics, and file-transfer tabs from the normal navigation so users see a simplified messaging interface.
- Added a persistent local chat store using AsyncStorage, including migration of the previous friend/profile keys, message history, delivery state, friend requests, and queued friend-control messages.
- Added friend request / accept / reject control messages. A newly entered peer ID remains pending until the other device accepts; messaging is disabled until acceptance.
- Added a final-device data acknowledgement (`data_ack`) in the native MeshRouter. The sender no longer treats a returned packet ID as proof of delivery; the UI changes to delivered only after the recipient device's acknowledgement arrives.
- Added bounded retransmission for data packets and duplicate-frame handling so lost ACKs can be recovered without duplicating stored chat messages.
- Refreshes reverse routes when duplicate data frames arrive, allowing replies to use a changed path.
- Increased the application frame allowance consistently across the router, BLE fragmentation and Wi-Fi Direct transport.
- Made visible connection errors user-oriented rather than exposing BLE/GATT/Wi-Fi Direct implementation messages.
- Kept the package/application ID unchanged and set the source version to 1.6 / versionCode 7.

## Verification performed in this environment

- TypeScript/TSX parser transpilation passed for the edited chat screen, home screen, and chat store. This checks syntax only, not full type correctness.
- A full `tsc --noEmit` run could not start because the extracted project has no installed `node_modules` and the Expo / NativeWind / Node type definitions are unavailable.
- An Android Release build was not performed: the configured Android SDK path (`/home/ubuntu/android-sdk`) is not present in this environment, and no Android SDK / `android.jar` or `apksigner` was found.
- No BLE, Wi-Fi Direct, two-device messaging, or three-device multi-hop test was run on physical Android phones. The APK supplied by the user was used as a reference artifact only; it was not modified or rebuilt here.
- Signing-certificate equivalence between the supplied APK and the project's signing configuration was not verified. Do not assume an in-place upgrade until the new build is signed with the same certificate.

## Important remaining engineering limitations

- The current native AES-GCM envelope uses a fixed application-wide seed (`INTERNAL_NETWORK_SEED`) embedded in the Android source. This is shared-network encryption, not authenticated end-to-end encryption. It must not be described as E2E-secure or used as protection for sensitive conversations until per-user key exchange, peer authentication, identity verification, and key rotation are implemented.
- Native relay queues are held in process memory. The sender's chat outbox is persisted locally, but an intermediate relay that is killed or restarted can lose its queued packets. Durable relay storage is still required for robust store-and-forward across process death.
- Android background execution, Android 15 permission/service behavior, BLE interoperability, Wi-Fi Direct group negotiation, and actual multi-hop routing remain unverified on physical devices.
- A device-level `data_ack` proves that the destination's native routing layer received the packet. It does not prove that the recipient read the message.

## Required acceptance test before release

1. Install the same signed Release build on two Android phones, accept required system permissions, and confirm peer discovery.
2. Add each device by Jesr ID; accept the incoming request on the second phone.
3. Send Arabic and Latin text in both directions. Confirm the received message appears once and the sender status changes only after the destination acknowledgement.
4. Repeat with a third phone acting as a relay and verify A → B → C delivery with internet and mobile data disabled.
5. Kill and reopen the app, then test delivery recovery, Bluetooth/Wi-Fi toggling, background operation, and Android crash logs.
