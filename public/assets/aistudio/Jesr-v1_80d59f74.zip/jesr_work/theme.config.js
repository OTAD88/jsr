/** @type {const} */
const themeColors = {
  primary: { light: '#426F61', dark: '#75AE9D' },
  background: { light: '#F3F6F2', dark: '#091511' },
  surface: { light: '#E8F0EB', dark: '#12241C' },
  foreground: { light: '#17231C', dark: '#F1F5F0' },
  muted: { light: '#607268', dark: '#A0B3A9' },
  border: { light: '#CAD8CF', dark: '#294137' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
