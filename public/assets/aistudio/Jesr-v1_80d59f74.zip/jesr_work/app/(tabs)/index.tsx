import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  AppState,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
  PermissionsAndroid,
  type Permission,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import {
  addMeshListener,
  getMeshSnapshot,
  isJesrNativeAvailable,
  startMesh,
  sendMeshSecureData,
  type JesrSnapshot,
} from "@/modules/jesr-network/src";
import {
  loadChatStore,
  makeLocalMessageId,
  makeControlId,
  updateChatStore,
  upsertFriend,
  upsertMessage,
  upsertRequest,
  type ChatMessage,
  type ChatStore,
  type Friend,
  type PendingControlType,
} from "@/lib/mesh/chat-store";

const C = {
  background: "#091511",
  backgroundSoft: "#0D1C16",
  surface: "#12241C",
  surfaceRaised: "#192D24",
  surfaceMuted: "#20372D",
  line: "#294137",
  accent: "#75AE9D",
  accentBright: "#9CCBBB",
  accentDim: "#426F61",
  text: "#F1F5F0",
  muted: "#A0B3A9",
  subtle: "#71857B",
  warning: "#D8B77A",
};

const initialSnapshot: JesrSnapshot = {
  available: false,
  active: false,
  localId: "",
  transportState: "stopped",
  batteryMode: "balanced",
  peers: [],
  routes: [],
  pendingPackets: 0,
  events: [],
};

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  return (parts.length > 1 ? `${parts[0][0]}${parts[1][0]}` : parts[0]?.slice(0, 2) || "ج").toUpperCase();
}

function formatTime(at: number) {
  if (!at) return "";
  const date = new Date(at);
  const now = new Date();
  if (date.toDateString() === now.toDateString()) return date.toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
  return date.toLocaleDateString("ar", { day: "numeric", month: "short" });
}

async function requestMeshPermissions() {
  if (Platform.OS !== "android") return;
  const api = Number(Platform.Version);
  const permissions: Permission[] = [];
  if (api >= 31) {
    permissions.push(
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
      PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
    );
  } else {
    permissions.push(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
  }
  permissions.push(api >= 33 ? PermissionsAndroid.PERMISSIONS.NEARBY_WIFI_DEVICES : PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
  const unique = [...new Set(permissions)];
  const result = await PermissionsAndroid.requestMultiple(unique);
  const denied = unique.filter((permission) => result[permission] !== PermissionsAndroid.RESULTS.GRANTED);
  if (denied.length) throw new Error("اسمح لجسر بالوصول إلى الأجهزة القريبة ليتمكن من البحث عن أصدقائك.");
  if (api >= 33) {
    await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
  }
}

function ChatRow({ friend, preview, time, status, onPress }: {
  friend: Friend;
  preview: string;
  time: string;
  status?: "queued" | "sending" | "delivered" | "failed";
  onPress: () => void;
}) {
  const scale = useRef(new Animated.Value(1)).current;
  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => Animated.spring(scale, { toValue: 0.985, useNativeDriver: true, speed: 30 }).start()}
      onPressOut={() => Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 24 }).start()}
      accessibilityRole="button"
      style={{ marginBottom: 5 }}
    >
      <Animated.View style={[styles.chatRow, { transform: [{ scale }] }]}>
        <View style={styles.avatarWrap}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{initials(friend.name)}</Text></View>
          <View style={styles.avatarHalo} />
        </View>
        <View style={styles.chatCopy}>
          <View style={styles.chatTitleLine}>
            <Text style={styles.friendName} numberOfLines={1}>{friend.name}</Text>
            <Text style={styles.chatTime}>{time}</Text>
          </View>
          <View style={styles.chatPreviewLine}>
            {status === "delivered" ? <Feather name="check-circle" size={13} color={C.accent} /> : null}
            {status === "sending" || status === "queued" ? <Feather name="clock" size={13} color={C.subtle} /> : null}
            {status === "failed" ? <Feather name="alert-circle" size={13} color={C.warning} /> : null}
            <Text style={styles.chatPreview} numberOfLines={1}>{preview || "ابدأ محادثة جديدة"}</Text>
          </View>
        </View>
      </Animated.View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const [store, setStore] = useState<ChatStore>({ displayName: "مستخدم جسر", friends: [], requests: [], pendingControls: [], messages: [] });
  const storeRef = useRef<ChatStore>({ displayName: "مستخدم جسر", friends: [], requests: [], pendingControls: [], messages: [] });
  const [snapshot, setSnapshot] = useState<JesrSnapshot>(initialSnapshot);
  const [search, setSearch] = useState("");
  const [addVisible, setAddVisible] = useState(false);
  const [friendName, setFriendName] = useState("");
  const [friendId, setFriendId] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [starting, setStarting] = useState(false);
  const glow = useRef(new Animated.Value(0.28)).current;
  const startLock = useRef(false);
  const outboxLock = useRef(false);
  const outboxAttempted = useRef(new Set<string>());
  const earlyAcks = useRef(new Set<string>());

  const reloadStore = useCallback(async () => {
    const next = await loadChatStore();
    storeRef.current = next;
    setStore(next);
  }, []);

  const refreshSnapshot = useCallback(async () => {
    try { setSnapshot(await getMeshSnapshot()); } catch { /* no technical details in the chat list */ }
  }, []);

  const retryPendingOutbox = useCallback(async () => {
    if (!isJesrNativeAvailable || outboxLock.current) return;
    outboxLock.current = true;
    try {
      const current = await loadChatStore();
      const pendingControls = current.pendingControls.filter((control) => !outboxAttempted.current.has(control.id));
      for (const control of pendingControls) {
        outboxAttempted.current.add(control.id);
        try {
          const packetId = await sendMeshSecureData(control.peerId, control.type, control.payload);
          const ackedEarly = earlyAcks.current.has(packetId);
          if (ackedEarly) earlyAcks.current.delete(packetId);
          const next = await updateChatStore((latest) => ({
            ...latest,
            pendingControls: ackedEarly
              ? latest.pendingControls.filter((item) => item.id !== control.id)
              : latest.pendingControls.map((item) => item.id === control.id ? { ...item, packetId } : item),
          }));
          storeRef.current = next;
          setStore(next);
        } catch {
          outboxAttempted.current.delete(control.id);
        }
      }
      const pending = current.messages.filter((message) =>
        message.direction === "outgoing" && (message.status === "queued" || message.status === "sending") && !outboxAttempted.current.has(message.id),
      );
      for (const message of pending) {
        outboxAttempted.current.add(message.id);
        try {
          const body = JSON.stringify({ messageId: message.id, text: message.text, createdAt: message.at });
          const packetId = await sendMeshSecureData(message.peerId, "message", body);
          const ackedEarly = earlyAcks.current.has(packetId);
          if (ackedEarly) earlyAcks.current.delete(packetId);
          const next = await updateChatStore((latest) => ({
            ...latest,
            messages: latest.messages.map((item) => item.id === message.id
              ? { ...item, packetId, status: ackedEarly ? "delivered" : "sending" }
              : item),
          }));
          storeRef.current = next;
          setStore(next);
        } catch {
          outboxAttempted.current.delete(message.id);
        }
      }
    } finally {
      outboxLock.current = false;
    }
  }, []);

  const ensureConnection = useCallback(async () => {
    if (!isJesrNativeAvailable || startLock.current) return;
    startLock.current = true;
    setStarting(true);
    try {
      const current = await getMeshSnapshot();
      setSnapshot(current);
      if (!current.active) {
        await requestMeshPermissions();
        const next = await startMesh("balanced");
        setSnapshot(next);
      }
      await retryPendingOutbox();
      setNotice("");
    } catch {
      setNotice("تعذر بدء الاتصال حالياً. سيحاول جسر مجدداً تلقائياً.");
    } finally {
      startLock.current = false;
      setStarting(false);
    }
  }, [retryPendingOutbox]);

  useEffect(() => {
    let alive = true;
    void Promise.all([reloadStore(), refreshSnapshot()]).finally(() => { if (alive) setLoading(false); });
    const meshSub = addMeshListener("onMeshState", (next) => {
      setSnapshot(next);
      if (next.active) void retryPendingOutbox();
    });
    const dataSub = addMeshListener("onDataReceived", (event) => {
      if (!event.nodeId || typeof event.data !== "string") return;
      if (event.dataType === "message") {
        void loadChatStore().then((saved) => {
          storeRef.current = saved;
          if (!saved.friends.some((item) => item.id === event.nodeId && item.status === "accepted")) return;
          let incoming: ChatMessage | null = null;
          try {
            const payload = JSON.parse(event.data) as { messageId?: unknown; text?: unknown; createdAt?: unknown };
            if (typeof payload.text === "string" && payload.text.length > 0) {
              incoming = {
                id: typeof payload.messageId === "string" ? payload.messageId : event.packetId || makeLocalMessageId(),
                packetId: event.packetId,
                peerId: event.nodeId!,
                text: payload.text,
                at: typeof payload.createdAt === "number" ? payload.createdAt : event.at,
                direction: "incoming",
                status: "delivered",
              };
            }
          } catch { /* support legacy plain-text payloads */ }
          if (!incoming && event.data) incoming = {
            id: event.packetId || makeLocalMessageId(), packetId: event.packetId, peerId: event.nodeId!,
            text: event.data, at: event.at || Date.now(), direction: "incoming", status: "delivered",
          };
          if (!incoming) return;
          void updateChatStore((current) => ({
            ...current,
            messages: upsertMessage(current.messages, incoming!),
          })).then((next) => { storeRef.current = next; setStore(next); });
        });
        return;
      }
      let controlName = "جهة اتصال";
      try {
        const payload = JSON.parse(event.data) as { name?: unknown };
        if (typeof payload.name === "string" && payload.name.trim()) controlName = payload.name.trim().slice(0, 48);
      } catch { /* invalid control payload is ignored */ }
      if (event.dataType === "friend_request") {
        void updateChatStore((current) => {
          const existing = current.friends.find((item) => item.id === event.nodeId);
          const pendingControls = existing?.status === "accepted" && !current.pendingControls.some((item) => item.peerId === event.nodeId && item.type === "friend_accept")
            ? [...current.pendingControls, { id: makeControlId(), peerId: event.nodeId!, type: "friend_accept" as PendingControlType, payload: JSON.stringify({ name: current.displayName }) }]
            : current.pendingControls;
          return {
            ...current,
            requests: existing?.status === "accepted" ? current.requests : upsertRequest(current.requests, { id: event.nodeId!, name: controlName, at: event.at || Date.now() }),
            pendingControls,
          };
        }).then((next) => { storeRef.current = next; setStore(next); void retryPendingOutbox(); });
      } else if (event.dataType === "friend_accept") {
        void updateChatStore((current) => ({
          ...current,
          friends: upsertFriend(current.friends, event.nodeId!, controlName, "accepted"),
          requests: current.requests.filter((item) => item.id !== event.nodeId),
          pendingControls: current.pendingControls.filter((item) => !(item.peerId === event.nodeId && item.type === "friend_request")),
        })).then((next) => { storeRef.current = next; setStore(next); });
      } else if (event.dataType === "friend_reject") {
        void updateChatStore((current) => ({
          ...current,
          friends: current.friends.filter((item) => !(item.id === event.nodeId && item.status === "pending")),
          pendingControls: current.pendingControls.filter((item) => !(item.peerId === event.nodeId && item.type === "friend_request")),
        })).then((next) => { storeRef.current = next; setStore(next); });
      }
    });
    const logSub = addMeshListener("onMeshLog", (event) => {
      if (!event.packetId) return;
      if (event.kind === "data_delivered") {
        const alreadyKnown = storeRef.current.messages.some((item) => item.packetId === event.packetId);
        if (!alreadyKnown) earlyAcks.current.add(event.packetId);
        void updateChatStore((current) => ({
          ...current,
          messages: current.messages.map((item) => item.packetId === event.packetId ? { ...item, status: "delivered" } : item),
          pendingControls: current.pendingControls.filter((item) => item.packetId !== event.packetId),
        })).then((next) => { storeRef.current = next; setStore(next); });
      } else if (event.kind === "data_delivery_failed") {
        void updateChatStore((current) => ({
          ...current,
          messages: current.messages.map((item) => item.packetId === event.packetId ? { ...item, status: "failed" } : item),
        })).then((next) => { storeRef.current = next; setStore(next); });
      }
    });
    const appSub = AppState.addEventListener("change", (state) => {
      if (state === "active") {
        void refreshSnapshot();
        void reloadStore();
        void ensureConnection();
      }
    });
    const pulse = Animated.loop(Animated.sequence([
      Animated.timing(glow, { toValue: 0.68, duration: 2600, useNativeDriver: true }),
      Animated.timing(glow, { toValue: 0.28, duration: 2600, useNativeDriver: true }),
    ]));
    pulse.start();
    void ensureConnection();
    return () => { alive = false; meshSub.remove(); dataSub.remove(); logSub.remove(); appSub.remove(); pulse.stop(); };
  }, [ensureConnection, glow, refreshSnapshot, reloadStore, retryPendingOutbox]);

  useFocusEffect(useCallback(() => { void reloadStore(); void refreshSnapshot(); }, [reloadStore, refreshSnapshot]));

  const conversations = useMemo(() => {
    const latest = new Map<string, (typeof store.messages)[number]>();
    for (const message of store.messages) {
      const old = latest.get(message.peerId);
      if (!old || old.at < message.at) latest.set(message.peerId, message);
    }
    return store.friends
      .filter((friend) => `${friend.name} ${friend.id}`.toLowerCase().includes(search.trim().toLowerCase()))
      .sort((a, b) => (latest.get(b.id)?.at ?? b.addedAt) - (latest.get(a.id)?.at ?? a.addedAt))
      .map((friend) => ({ friend, message: latest.get(friend.id) }));
  }, [store.friends, store.messages, search]);

  async function addFriend() {
    const id = friendId.trim();
    const name = friendName.trim() || "صديق جديد";
    if (!id || id === snapshot.localId) {
      setNotice("أدخل معرّف صديق آخر.");
      return;
    }
    if (id.length < 8 || id.length > 128) {
      setNotice("المعرّف غير صالح. استخدم المعرف الذي شاركه صديقك من داخل جسر.");
      return;
    }
    const existing = storeRef.current.friends.find((item) => item.id === id);
    if (existing?.status === "accepted") {
      setNotice("هذا الشخص موجود بالفعل في قائمة أصدقائك.");
      return;
    }
    if (existing?.status === "pending") {
      setNotice("طلب الصداقة موجود بالفعل وينتظر الرد.");
      return;
    }
    const next = await updateChatStore((current) => ({
      ...current,
      friends: upsertFriend(current.friends, id, name, "pending", "outgoing"),
      pendingControls: current.pendingControls.some((item) => item.peerId === id && item.type === "friend_request")
        ? current.pendingControls
        : [...current.pendingControls, { id: makeControlId(), peerId: id, type: "friend_request", payload: JSON.stringify({ name: current.displayName }) }],
    }));
    storeRef.current = next;
    setStore(next);
    setFriendName("");
    setFriendId("");
    setAddVisible(false);
    setNotice("حُفظ طلب الصداقة وسيُرسل تلقائياً عند توفر مسار اتصال. تبدأ المحادثة بعد موافقة الطرف الآخر.");
    void retryPendingOutbox();
  }

  async function respondToRequest(requestId: string, accept: boolean) {
    const next = await updateChatStore((current) => {
      const request = current.requests.find((item) => item.id === requestId);
      if (!request) return current;
      const type: PendingControlType = accept ? "friend_accept" : "friend_reject";
      return {
        ...current,
        requests: current.requests.filter((item) => item.id !== requestId),
        friends: accept
          ? upsertFriend(current.friends, request.id, request.name, "accepted")
          : current.friends,
        pendingControls: [...current.pendingControls.filter((item) => !(item.peerId === requestId && item.type === type)), {
          id: makeControlId(), peerId: requestId, type, payload: JSON.stringify({ name: current.displayName }),
        }],
      };
    });
    storeRef.current = next;
    setStore(next);
    void retryPendingOutbox();
  }

  async function shareMyId() {
    if (!snapshot.localId) {
      setNotice("جارٍ تجهيز معرّف جهازك. أعد المحاولة بعد لحظة.");
      return;
    }
    try {
      await Share.share({ message: `أضفني على جسر بهذا المعرّف:\n${snapshot.localId}` });
    } catch {
      setNotice("تعذرت مشاركة المعرّف.");
    }
  }

  const onlineCount = snapshot.peers.filter((peer) => peer.connected).length;
  const statusLabel = !isJesrNativeAvailable ? "يتطلب نسخة Android كاملة" : onlineCount > 0 ? "متصل بجهاز قريب" : starting ? "جارٍ تهيئة الشبكة" : snapshot.active ? "يبحث عن أجهزة قريبة" : "سيعيد جسر الاتصال تلقائياً";

  return (
    <ScreenContainer edges={["top", "left", "right"]} safeAreaClassName="bg-[#091511]">
      <View style={styles.page}>
        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          refreshControl={<RefreshControl refreshing={refreshing} tintColor={C.accent} onRefresh={async () => { setRefreshing(true); await Promise.all([reloadStore(), refreshSnapshot()]); setRefreshing(false); }} />}
        >
          <View style={styles.topBar}>
            <View style={styles.brandBlock}>
              <View style={styles.brandMark}><Feather name="message-circle" size={19} color={C.background} /></View>
              <View>
                <Text style={styles.brand}>جسر</Text>
                <Text style={styles.tagline}>مساحة تواصلك الخاصة</Text>
              </View>
            </View>
            <Pressable onPress={() => void shareMyId()} style={({ pressed }) => [styles.profileButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="مشاركة معرفي">
              <Feather name="user-plus" size={18} color={C.accentBright} />
            </Pressable>
          </View>

          <View style={styles.hero}>
            <Animated.View style={[styles.heroOrb, { opacity: glow }]} />
            <View style={styles.heroOrbSmall} />
            <View style={styles.heroContent}>
              <View style={styles.heroEyebrowRow}>
                <View style={[styles.statusDot, onlineCount > 0 && styles.statusDotOn]} />
                <Text style={styles.heroEyebrow}>{statusLabel}</Text>
              </View>
              <Text style={styles.heroTitle}>ابقَ على اتصال،{`\n`}أينما كنت.</Text>
              <Text style={styles.heroSubtitle}>رسائلك ومحادثاتك في مكان واحد، بتجربة هادئة وبسيطة.</Text>
            </View>
            <View style={styles.heroFooter}>
              <View style={styles.heroFooterLine} />
              <Text style={styles.heroFooterText}>{store.friends.length} جهة اتصال</Text>
            </View>
          </View>

          <View style={styles.sectionHeader}>
            <View>
              <Text style={styles.sectionTitle}>المحادثات</Text>
              <Text style={styles.sectionCaption}>الأشخاص الذين أضفتهم إلى جسر</Text>
            </View>
            <Pressable onPress={() => setAddVisible(true)} style={({ pressed }) => [styles.addButton, pressed && styles.pressed]} accessibilityRole="button">
              <Feather name="plus" size={17} color={C.background} />
              <Text style={styles.addButtonText}>محادثة جديدة</Text>
            </Pressable>
          </View>

          <View style={styles.searchBox}>
            <Feather name="search" size={17} color={C.subtle} />
            <TextInput value={search} onChangeText={setSearch} placeholder="ابحث في المحادثات" placeholderTextColor={C.subtle} style={styles.searchInput} returnKeyType="search" />
            {search.length > 0 ? <Pressable onPress={() => setSearch("")} hitSlop={8}><Feather name="x-circle" size={16} color={C.subtle} /></Pressable> : null}
          </View>

          {store.requests.length > 0 ? (
            <View style={styles.requestsPanel}>
              <View style={styles.requestsHeading}><Text style={styles.requestsTitle}>طلبات الصداقة</Text><Text style={styles.requestsCount}>{store.requests.length}</Text></View>
              {store.requests.map((request) => (
                <View key={request.id} style={styles.requestRow}>
                  <View style={styles.requestAvatar}><Feather name="user" size={17} color={C.accentBright} /></View>
                  <View style={styles.requestCopy}><Text style={styles.requestName}>{request.name}</Text><Text style={styles.requestId} numberOfLines={1}>{request.id}</Text></View>
                  <Pressable onPress={() => void respondToRequest(request.id, true)} style={styles.acceptButton}><Feather name="check" size={15} color={C.background} /></Pressable>
                  <Pressable onPress={() => void respondToRequest(request.id, false)} style={styles.rejectButton}><Feather name="x" size={15} color={C.muted} /></Pressable>
                </View>
              ))}
            </View>
          ) : null}

          {loading ? (
            <View style={styles.loadingState}><ActivityIndicator color={C.accent} /><Text style={styles.loadingText}>جارٍ تجهيز محادثاتك…</Text></View>
          ) : conversations.length > 0 ? (
            <View style={styles.chatList}>
              {conversations.map(({ friend, message }) => (
                <ChatRow
                  key={friend.id}
                  friend={friend}
                  preview={friend.status === "pending" ? "بانتظار قبول طلب الصداقة" : message?.text ?? "ابدأ محادثة جديدة"}
                  time={message ? formatTime(message.at) : ""}
                  status={message?.direction === "outgoing" ? message.status : undefined}
                  onPress={() => friend.status === "accepted" ? router.push({ pathname: "/chat/[id]", params: { id: friend.id } }) : setNotice("ستُفتح المحادثة بعد قبول طلب الصداقة.")}
                />
              ))}
            </View>
          ) : (
            <View style={styles.emptyState}>
              <View style={styles.emptyIcon}><Feather name="message-square" size={27} color={C.accentBright} /></View>
              <Text style={styles.emptyTitle}>{search ? "لا توجد نتائج" : "مساحتك تبدأ هنا"}</Text>
              <Text style={styles.emptyText}>{search ? "جرّب اسماً أو معرّفاً مختلفاً." : "أضف صديقاً باستخدام معرّف جسر، وستظهر محادثاتك هنا."}</Text>
              {!search ? <Pressable onPress={() => setAddVisible(true)} style={({ pressed }) => [styles.emptyAction, pressed && styles.pressed]}><Feather name="plus" size={16} color={C.background} /><Text style={styles.emptyActionText}>إضافة صديق</Text></Pressable> : null}
            </View>
          )}

          {notice ? <Pressable onPress={() => setNotice("")} style={styles.notice}><Feather name="info" size={16} color={C.accentBright} /><Text style={styles.noticeText}>{notice}</Text><Feather name="x" size={14} color={C.subtle} /></Pressable> : null}
          <View style={styles.bottomSpace} />
        </ScrollView>

        <Modal visible={addVisible} animationType="fade" transparent onRequestClose={() => setAddVisible(false)}>
          <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setAddVisible(false)} />
            <View style={styles.modalCard}>
              <View style={styles.modalHandle} />
              <View style={styles.modalHeader}>
                <View><Text style={styles.modalTitle}>إضافة صديق</Text><Text style={styles.modalSubtitle}>أدخل المعرّف الذي شاركه معك</Text></View>
                <Pressable onPress={() => setAddVisible(false)} style={styles.modalClose}><Feather name="x" size={18} color={C.muted} /></Pressable>
              </View>
              <Text style={styles.fieldLabel}>اسم الصديق</Text>
              <TextInput value={friendName} onChangeText={setFriendName} placeholder="الاسم الذي سيظهر في المحادثة" placeholderTextColor={C.subtle} style={styles.fieldInput} autoCorrect={false} />
              <Text style={styles.fieldLabel}>معرّف جسر</Text>
              <TextInput value={friendId} onChangeText={setFriendId} placeholder="ألصق المعرّف هنا" placeholderTextColor={C.subtle} style={styles.fieldInput} autoCapitalize="none" autoCorrect={false} />
              <Pressable onPress={() => void addFriend()} style={({ pressed }) => [styles.modalPrimary, pressed && styles.pressed]}>
                <Text style={styles.modalPrimaryText}>إرسال طلب الصداقة</Text><Feather name="arrow-left" size={17} color={C.background} />
              </Pressable>
              <Text style={styles.modalFootnote}>يمكنك مشاركة معرّفك من زر الشخص أعلى الشاشة.</Text>
            </View>
          </KeyboardAvoidingView>
        </Modal>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  content: { paddingHorizontal: 20, paddingTop: 13, paddingBottom: 30 },
  topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 },
  brandBlock: { flexDirection: "row", alignItems: "center", gap: 11 },
  brandMark: { width: 40, height: 40, borderRadius: 14, backgroundColor: C.accent, alignItems: "center", justifyContent: "center" },
  brand: { color: C.text, fontSize: 21, fontWeight: "800", textAlign: "left" },
  tagline: { color: C.subtle, fontSize: 10, marginTop: 1, textAlign: "left" },
  profileButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, borderColor: C.line, backgroundColor: C.surface, alignItems: "center", justifyContent: "center" },
  hero: { minHeight: 190, borderRadius: 25, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, overflow: "hidden", marginBottom: 27 },
  heroOrb: { position: "absolute", width: 245, height: 245, borderRadius: 130, backgroundColor: C.accentDim, right: -95, top: -120 },
  heroOrbSmall: { position: "absolute", width: 150, height: 150, borderRadius: 90, borderWidth: 1, borderColor: "#527B6D", opacity: 0.34, right: -35, top: -45 },
  heroContent: { paddingHorizontal: 21, paddingTop: 21, paddingBottom: 18, alignItems: "flex-start" },
  heroEyebrowRow: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 13 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.warning },
  statusDotOn: { backgroundColor: C.accentBright },
  heroEyebrow: { color: C.accentBright, fontSize: 11, fontWeight: "700" },
  heroTitle: { color: C.text, fontSize: 28, fontWeight: "800", lineHeight: 35, textAlign: "left", letterSpacing: -0.3 },
  heroSubtitle: { color: C.muted, fontSize: 12, lineHeight: 19, marginTop: 8, maxWidth: "88%", textAlign: "left" },
  heroFooter: { borderTopWidth: 1, borderTopColor: "rgba(117,174,157,0.16)", paddingHorizontal: 21, paddingVertical: 11, flexDirection: "row", alignItems: "center", gap: 9 },
  heroFooterLine: { width: 18, height: 2, borderRadius: 2, backgroundColor: C.accent },
  heroFooterText: { color: C.subtle, fontSize: 10 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 13 },
  sectionTitle: { color: C.text, fontSize: 20, fontWeight: "800", textAlign: "left" },
  sectionCaption: { color: C.subtle, fontSize: 10, marginTop: 4, textAlign: "left" },
  addButton: { minHeight: 39, borderRadius: 13, backgroundColor: C.accent, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 6 },
  addButtonText: { color: C.background, fontWeight: "800", fontSize: 11 },
  searchBox: { height: 47, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, borderRadius: 14, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 15 },
  searchInput: { flex: 1, color: C.text, textAlign: "right", paddingVertical: 0, fontSize: 13 },
  requestsPanel: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, borderRadius: 18, padding: 12, marginBottom: 16 },
  requestsHeading: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 8 },
  requestsTitle: { color: C.text, fontSize: 13, fontWeight: "800" },
  requestsCount: { minWidth: 20, height: 20, overflow: "hidden", textAlign: "center", textAlignVertical: "center", color: C.background, fontSize: 10, fontWeight: "900", backgroundColor: C.accent, borderRadius: 10 },
  requestRow: { minHeight: 56, flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, marginTop: 4 },
  requestAvatar: { width: 36, height: 36, borderRadius: 13, backgroundColor: C.surfaceMuted, alignItems: "center", justifyContent: "center" },
  requestCopy: { flex: 1 },
  requestName: { color: C.text, fontSize: 12, fontWeight: "700", textAlign: "right" },
  requestId: { color: C.subtle, fontSize: 9, marginTop: 3, textAlign: "right" },
  acceptButton: { width: 34, height: 34, borderRadius: 12, backgroundColor: C.accent, alignItems: "center", justifyContent: "center" },
  rejectButton: { width: 34, height: 34, borderRadius: 12, backgroundColor: C.surfaceRaised, borderWidth: 1, borderColor: C.line, alignItems: "center", justifyContent: "center" },
  chatList: { paddingTop: 2 },
  chatRow: { minHeight: 76, flexDirection: "row", alignItems: "center", paddingHorizontal: 2, paddingVertical: 9, borderBottomWidth: 1, borderBottomColor: "rgba(117,174,157,0.10)" },
  avatarWrap: { width: 54, height: 54, alignItems: "center", justifyContent: "center", marginRight: 13 },
  avatarHalo: { position: "absolute", width: 53, height: 53, borderRadius: 27, borderWidth: 1, borderColor: "rgba(117,174,157,0.26)" },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: C.surfaceMuted, borderWidth: 1, borderColor: C.accentDim, alignItems: "center", justifyContent: "center" },
  avatarText: { color: C.accentBright, fontSize: 15, fontWeight: "800" },
  chatCopy: { flex: 1, justifyContent: "center", paddingVertical: 3 },
  chatTitleLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  friendName: { color: C.text, fontSize: 14, fontWeight: "700", flex: 1, textAlign: "right" },
  chatTime: { color: C.subtle, fontSize: 10 },
  chatPreviewLine: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 7 },
  chatPreview: { color: C.muted, fontSize: 11, flex: 1, textAlign: "right" },
  loadingState: { paddingVertical: 48, alignItems: "center", gap: 11 },
  loadingText: { color: C.subtle, fontSize: 11 },
  emptyState: { minHeight: 225, alignItems: "center", justifyContent: "center", paddingHorizontal: 27, marginTop: 10, borderRadius: 22, backgroundColor: "rgba(18,36,28,0.62)", borderWidth: 1, borderColor: C.line },
  emptyIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: C.surfaceMuted, alignItems: "center", justifyContent: "center", marginBottom: 15 },
  emptyTitle: { color: C.text, fontSize: 17, fontWeight: "800" },
  emptyText: { color: C.muted, fontSize: 11, lineHeight: 19, textAlign: "center", marginTop: 8 },
  emptyAction: { marginTop: 17, backgroundColor: C.accent, borderRadius: 12, minHeight: 40, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", gap: 7 },
  emptyActionText: { color: C.background, fontWeight: "800", fontSize: 11 },
  notice: { flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, borderRadius: 13, padding: 11, marginTop: 15 },
  noticeText: { color: C.muted, fontSize: 10, flex: 1, lineHeight: 16, textAlign: "right" },
  retryConnection: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, padding: 13 },
  retryText: { color: C.accentBright, fontSize: 10, fontWeight: "700" },
  bottomSpace: { height: 30 },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", padding: 12, backgroundColor: "rgba(0,0,0,0.68)" },
  modalCard: { backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, borderRadius: 26, paddingHorizontal: 20, paddingTop: 10, paddingBottom: 24 },
  modalHandle: { alignSelf: "center", width: 38, height: 4, borderRadius: 3, backgroundColor: C.surfaceMuted, marginBottom: 19 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 18 },
  modalTitle: { color: C.text, fontSize: 21, fontWeight: "800", textAlign: "left" },
  modalSubtitle: { color: C.subtle, fontSize: 11, marginTop: 4, textAlign: "left" },
  modalClose: { width: 35, height: 35, borderRadius: 12, backgroundColor: C.surfaceRaised, alignItems: "center", justifyContent: "center" },
  fieldLabel: { color: C.accentBright, fontSize: 11, fontWeight: "700", marginBottom: 7, marginTop: 5, textAlign: "right" },
  fieldInput: { minHeight: 48, borderRadius: 13, borderWidth: 1, borderColor: C.line, backgroundColor: C.backgroundSoft, color: C.text, paddingHorizontal: 13, fontSize: 13, textAlign: "right", marginBottom: 9 },
  modalPrimary: { minHeight: 49, borderRadius: 14, backgroundColor: C.accent, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9, marginTop: 8 },
  modalPrimaryText: { color: C.background, fontSize: 12, fontWeight: "900" },
  modalFootnote: { color: C.subtle, fontSize: 10, textAlign: "center", marginTop: 13 },
  pressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
});
