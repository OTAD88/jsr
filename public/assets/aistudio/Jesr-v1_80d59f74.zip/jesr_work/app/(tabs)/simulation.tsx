import { useEffect, useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Svg, { Circle, Line, Text as SvgText } from "react-native-svg";
import { ScreenContainer } from "@/components/screen-container";
import { createDefaultCustomScenario, runCustomScenario, validateCustomScenario, type CustomScenario } from "@/lib/mesh/simulation";
import { createLinkFromSelection, parseCustomTtlDraft, removeNodeById } from "@/lib/mesh/custom-builder";

const palette = {
  background: "#0D1722",
  panel: "#142330",
  panelRaised: "#192B38",
  line: "#2A3D49",
  text: "#EAF1F4",
  muted: "#9AAAB3",
  teal: "#20C7B4",
  amber: "#E6AA5A",
  red: "#E57676",
  blue: "#76B7D8",
};

type Transport = "BLE" | "Wi‑Fi Direct";
type Scenario = "three-hop" | "mixed" | "failure";

interface Hop { from: string; to: string; transport: Transport; }
interface SimulationResult { delivered: boolean; path: string[]; hops: Hop[]; events: string[]; reason?: string; }

const scenarios: Record<Scenario, { title: string; description: string; hops: Hop[] }> = {
  "three-hop": {
    title: "ثلاث عقد متتابعة",
    description: "مسار A → B → C من دون وصلة مباشرة A → C.",
    hops: [
      { from: "A", to: "B", transport: "BLE" },
      { from: "B", to: "C", transport: "BLE" },
    ],
  },
  mixed: {
    title: "نقل مختلط",
    description: "يمر المسار عبر BLE ثم Wi‑Fi Direct في القفزة التالية.",
    hops: [
      { from: "A", to: "B", transport: "BLE" },
      { from: "B", to: "C", transport: "Wi‑Fi Direct" },
    ],
  },
  failure: {
    title: "فقدان القفزة التالية",
    description: "تفشل B → C، ثم يحاول الراوتر المسار البديل عبر D.",
    hops: [
      { from: "A", to: "B", transport: "BLE" },
      { from: "B", to: "C", transport: "Wi‑Fi Direct" },
      { from: "B", to: "D", transport: "BLE" },
      { from: "D", to: "C", transport: "BLE" },
    ],
  },
};

function Graph({ result, failedHop }: { result: SimulationResult | null; failedHop: boolean }) {
  const nodes = ["A", "B", "C", ...(result?.hops.some((hop) => hop.to === "D") ? ["D"] : [])];
  const positions: Record<string, { x: number; y: number }> = { A: { x: 42, y: 88 }, B: { x: 142, y: 48 }, C: { x: 258, y: 88 }, D: { x: 142, y: 132 } };
  const active = new Set(result?.hops.map((hop) => `${hop.from}-${hop.to}`) ?? []);
  return (
    <View style={styles.graphShell}>
      <Svg width="300" height="178">
        {result?.hops.map((hop) => {
          const from = positions[hop.from]; const to = positions[hop.to];
          const isFailed = failedHop && hop.from === "B" && hop.to === "C";
          return <Line key={`${hop.from}-${hop.to}`} x1={from.x} y1={from.y} x2={to.x} y2={to.y} stroke={isFailed ? palette.red : active.has(`${hop.from}-${hop.to}`) ? palette.teal : palette.line} strokeWidth={isFailed ? 3 : 2} strokeDasharray={isFailed ? "6 5" : undefined} />;
        })}
        {nodes.map((node) => { const p = positions[node]; return <Svg key={node}><Circle cx={p.x} cy={p.y} r="19" fill={node === "A" ? palette.text : palette.teal} /><SvgText x={p.x} y={p.y + 6} fill={palette.background} fontSize="15" fontWeight="700" textAnchor="middle">{node}</SvgText></Svg>; })}
      </Svg>
      <View style={styles.legend}><Text style={styles.legendText}><Text style={{ color: palette.teal }}>●</Text> مسار مستخدم</Text><Text style={styles.legendText}><Text style={{ color: palette.red }}>--</Text> قفزة فاشلة</Text></View>
    </View>
  );
}

function simulate(scenario: Scenario, ttl: number, loopGuard: boolean): SimulationResult {
  const base = scenarios[scenario].hops;
  const events = [`إنشاء Ping من A إلى C · TTL=${ttl}`, "فحص المسار ومنع العقد المكررة"];
  if (loopGuard) events.push("تم تفعيل حماية الحلقة");
  if (scenario === "failure") {
    events.push("فشل الرابط B → C · البحث عن مسار بديل", "اختيار A → B → D → C", "ACK عاد إلى A عبر المسار البديل");
    return { delivered: true, path: ["A", "B", "D", "C"], hops: base, events };
  }
  if (ttl < 2) return { delivered: false, path: ["A", "B"], hops: base, events: [...events, "انتهى TTL قبل الوصول إلى الوجهة"], reason: "انتهى TTL" };
  const path = ["A", "B", "C"];
  const transportText = scenario === "mixed" ? "BLE ثم Wi‑Fi Direct" : "BLE ثم BLE";
  return { delivered: true, path, hops: base, events: [...events, `تم تمرير القفزات: ${transportText}`, "وصلت الحزمة إلى C", "عاد ACK إلى A"] };
}

export default function SimulationScreen() {
  const [scenario, setScenario] = useState<Scenario>("three-hop");
  const [ttl, setTtl] = useState(3);
  const [loopGuard, setLoopGuard] = useState(true);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [custom, setCustom] = useState<CustomScenario>(() => createDefaultCustomScenario());
  const [customTtlText, setCustomTtlText] = useState("8");
  const [linkFromId, setLinkFromId] = useState<string | null>(null);
  const [linkToId, setLinkToId] = useState<string | null>(null);
  const [customResult, setCustomResult] = useState<ReturnType<typeof runCustomScenario> | null>(null);
  const [customNotice, setCustomNotice] = useState<string | null>(null);
  const current = scenarios[scenario];
  const failedHop = scenario === "failure" && !!result;
  const summary = useMemo(() => result ? (result.delivered ? "تم التسليم بنجاح" : "فشل التسليم") : "لم تبدأ المحاكاة", [result]);

  useEffect(() => {
    void AsyncStorage.getItem("jesr.customScenario.v2").then((raw) => {
      if (!raw) return;
      try {
        const parsed: unknown = JSON.parse(raw);
        if (validateCustomScenario(parsed)) { setCustom(parsed); setCustomTtlText(String(parsed.ttl)); }
        else setCustomNotice("تم تجاهل سيناريو محفوظ غير صالح");
      } catch { setCustomNotice("تعذر قراءة السيناريو المحفوظ"); }
    });
  }, []);

  function updateCustom(update: (current: CustomScenario) => CustomScenario) {
    setCustom((current) => update(current));
    setCustomResult(null);
  }

  function addCustomNode() {
    updateCustom((current) => {
      const used = new Set(current.nodes.map((node) => node.id));
      const id = ["A", "B", "C", "D", "E", "F", "G"].find((candidate) => !used.has(candidate));
      return id ? { ...current, nodes: [...current.nodes, { id, enabled: true }] } : current;
    });
  }

  function addCustomLink() {
    const selectedLabel = linkFromId && linkToId ? `إنشاء رابط ${linkFromId} ↔ ${linkToId}` : "حدد طرفي الرابط أولاً";
    const preview = createLinkFromSelection(custom, linkFromId, linkToId);
    if (!preview) { setCustomNotice(selectedLabel); return; }
    updateCustom((current) => {
      const link = createLinkFromSelection(current, linkFromId, linkToId);
      return link ? { ...current, links: [...current.links, link] } : current;
    });
    setCustomNotice(`تم إنشاء الرابط ${preview.from} ↔ ${preview.to}`);
    setLinkFromId(null);
    setLinkToId(null);
  }

  function deleteCustomNode(id: string) {
    updateCustom((current) => removeNodeById(current, id));
    setLinkFromId((value) => value === id ? null : value);
    setLinkToId((value) => value === id ? null : value);
  }

  function runCustom() {
    const ttl = parseCustomTtlDraft(customTtlText);
    if (ttl === null) { setCustomNotice("TTL يجب أن يكون رقماً صحيحاً من 1 إلى 32"); return; }
    setCustom((current) => {
      const next = { ...current, ttl };
      setCustomResult(runCustomScenario(next));
      return next;
    });
  }

  function cycleEndpoint(field: "sourceId" | "targetId") {
    const enabled = custom.nodes.filter((node) => node.enabled);
    if (enabled.length < 2) return;
    const currentIndex = Math.max(0, enabled.findIndex((node) => node.id === custom[field]));
    const next = enabled[(currentIndex + 1) % enabled.length].id;
    updateCustom((current) => ({ ...current, [field]: next, ...(field === "sourceId" && next === current.targetId ? { targetId: enabled[(currentIndex + 2) % enabled.length].id } : {}) }));
  }

  async function saveCustom() {
    const ttl = parseCustomTtlDraft(customTtlText);
    const toSave = ttl === null ? custom : { ...custom, ttl };
    if (ttl === null || !validateCustomScenario(toSave)) { setCustomNotice("لا يمكن الحفظ: TTL يجب أن يكون من 1 إلى 32 وبقية البيانات صحيحة"); return; }
    setCustom(toSave);
    await AsyncStorage.setItem("jesr.customScenario.v2", JSON.stringify(toSave));
    setCustomNotice("تم حفظ السيناريو محلياً");
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} safeAreaClassName="bg-[#0D1722]">
      <ScrollView style={styles.page} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={styles.title}>مختبر محاكاة الشبكة</Text><Text style={styles.subtitle}>اختبر التوجيه متعدد القفزات دون أجهزة حقيقية</Text></View><View style={styles.labBadge}><Text style={styles.labBadgeText}>LAB</Text></View></View>
        <View style={styles.info}><Text style={styles.infoTitle}>Network Simulation Lab</Text><Text style={styles.infoText}>أنشئ سيناريو، شغّل حزمة Ping، وشاهد القفزات والنقل ونتيجة ACK خطوة بخطوة.</Text></View>
        <Text style={styles.sectionTitle}>السيناريو</Text>
        <View style={styles.scenarios}>{(Object.keys(scenarios) as Scenario[]).map((key) => <Pressable key={key} onPress={() => { setScenario(key); setResult(null); }} style={[styles.scenario, scenario === key && styles.scenarioSelected]}><Text style={[styles.scenarioTitle, scenario === key && { color: palette.teal }]}>{scenarios[key].title}</Text><Text style={styles.scenarioText}>{scenarios[key].description}</Text></Pressable>)}</View>
        <View style={styles.controls}><View style={styles.control}><Text style={styles.controlLabel}>TTL</Text><View style={styles.stepper}><Pressable onPress={() => setTtl(Math.max(1, ttl - 1))} style={styles.step}><Text style={styles.stepText}>−</Text></Pressable><Text style={styles.ttl}>{ttl}</Text><Pressable onPress={() => setTtl(Math.min(8, ttl + 1))} style={styles.step}><Text style={styles.stepText}>+</Text></Pressable></View></View><Pressable onPress={() => setLoopGuard((value) => !value)} style={styles.toggleRow}><View style={[styles.toggle, loopGuard && styles.toggleOn]}><View style={[styles.toggleDot, loopGuard && styles.toggleDotOn]} /></View><Text style={styles.controlLabel}>منع الحلقات</Text></Pressable></View>
        <Pressable onPress={() => setResult(simulate(scenario, ttl, loopGuard))} style={styles.runButton}><Text style={styles.runButtonText}>تشغيل المحاكاة</Text></Pressable>
        <Text style={styles.sectionTitle}>الطوبولوجيا</Text><Graph result={result ?? { delivered: false, path: [], hops: current.hops, events: [] }} failedHop={failedHop} />
        <View style={[styles.result, result?.delivered ? styles.resultSuccess : result ? styles.resultFailure : styles.resultIdle]}><Text style={styles.resultTitle}>{summary}</Text>{result && <Text style={styles.resultPath}>المسار: {result.path.join(" → ")}</Text>}</View>
        <Text style={styles.sectionTitle}>سجل الأحداث</Text><View style={styles.log}>{(result?.events ?? ["اضغط «تشغيل المحاكاة» لبدء الاختبار"]).map((event, index) => <View key={`${event}-${index}`} style={styles.logRow}><Text style={styles.logIndex}>{String(index + 1).padStart(2, "0")}</Text><Text style={styles.logText}>{event}</Text></View>)}</View>
        <View style={styles.customHeader}><View><Text style={styles.sectionTitle}>منشئ سيناريو مخصص</Text><Text style={styles.customNote}>يشغّل MeshRouter الحقيقي ويحفظ محلياً.</Text></View><Text style={styles.customBadge}>V2</Text></View>
        <View style={styles.customPanel}>
          <Text style={styles.label}>اسم السيناريو</Text>
          <TextInput value={custom.name} onChangeText={(name) => updateCustom((current) => ({ ...current, name }))} style={styles.nameInput} placeholderTextColor={palette.muted} />
          <View style={styles.builderToolbar}><Pressable onPress={addCustomNode} style={styles.smallButton}><Text style={styles.smallButtonText}>+ إضافة عقدة</Text></Pressable></View>
          <Text style={styles.builderLabel}>العقد</Text>
          <View style={styles.nodeRows}>{custom.nodes.map((node) => <View key={node.id} style={styles.nodeRow}><Text style={styles.builderLink}>{node.id}</Text><Pressable onPress={() => deleteCustomNode(node.id)} disabled={custom.nodes.length <= 2} style={styles.deleteButton}><Text style={styles.deleteText}>{custom.nodes.length <= 2 ? "حد أدنى" : "حذف"}</Text></Pressable></View>)}</View>
          <View style={styles.endpointRow}><Pressable onPress={() => cycleEndpoint("sourceId")} style={styles.endpoint}><Text style={styles.endpointLabel}>المصدر</Text><Text style={styles.endpointValue}>{custom.sourceId}</Text></Pressable><Pressable onPress={() => cycleEndpoint("targetId")} style={styles.endpoint}><Text style={styles.endpointLabel}>الوجهة</Text><Text style={styles.endpointValue}>{custom.targetId}</Text></Pressable></View>
          <Text style={styles.builderLabel}>طرفا الرابط الجديد</Text>
          <View style={styles.pickerGroup}><Text style={styles.pickerLabel}>العقدة الأولى: {linkFromId ?? "غير محددة"}</Text><View style={styles.pickerRow}>{custom.nodes.map((node) => <Pressable key={`from-${node.id}`} onPress={() => setLinkFromId(node.id)} style={[styles.nodeChoice, linkFromId === node.id && styles.nodeChoiceSelected]}><Text style={styles.nodeChoiceText}>{node.id}</Text></Pressable>)}</View></View>
          <View style={styles.pickerGroup}><Text style={styles.pickerLabel}>العقدة الثانية: {linkToId ?? "غير محددة"}</Text><View style={styles.pickerRow}>{custom.nodes.map((node) => <Pressable key={`to-${node.id}`} onPress={() => setLinkToId(node.id)} style={[styles.nodeChoice, linkToId === node.id && styles.nodeChoiceSelected]}><Text style={styles.nodeChoiceText}>{node.id}</Text></Pressable>)}</View></View>
          <Text style={styles.linkPreview}>{linkFromId && linkToId ? `إنشاء رابط ${linkFromId} ↔ ${linkToId}` : "حدد العقدتين لإنشاء الرابط"}</Text>
          <Pressable onPress={addCustomLink} style={styles.addLinkButton}><Text style={styles.addLinkText}>إنشاء الرابط المحدد</Text></Pressable>
          <Text style={styles.builderLabel}>الروابط وخصائصها</Text>
          <View style={styles.builderRows}>{custom.links.map((link) => <View key={link.id} style={styles.linkEditor}><View style={styles.builderRow}><Text style={styles.builderLink}>{link.from} ↔ {link.to}</Text><Pressable onPress={() => updateCustom((current) => ({ ...current, links: current.links.filter((item) => item.id !== link.id) }))} style={styles.deleteButton}><Text style={styles.deleteText}>حذف الرابط</Text></Pressable></View><View style={styles.linkFields}><Pressable onPress={() => updateCustom((current) => ({ ...current, links: current.links.map((item) => item.id === link.id ? { ...item, transport: item.transport === "ble" ? "wifi-direct" : "ble" } : item) }))} style={styles.fieldButton}><Text style={styles.fieldText}>{link.transport === "ble" ? "BLE" : "Wi‑Fi Direct"}</Text></Pressable><TextInput value={String(link.quality)} onChangeText={(value) => updateCustom((current) => ({ ...current, links: current.links.map((item) => item.id === link.id ? { ...item, quality: Math.max(0, Math.min(100, Number(value.replace(/[^0-9]/g, "")) || 0)) } : item) }))} keyboardType="number-pad" style={styles.linkInput} /><Text style={styles.unit}>جودة</Text><TextInput value={String(link.lossPercent)} onChangeText={(value) => updateCustom((current) => ({ ...current, links: current.links.map((item) => item.id === link.id ? { ...item, lossPercent: Math.max(0, Math.min(100, Number(value.replace(/[^0-9]/g, "")) || 0)) } : item) }))} keyboardType="number-pad" style={styles.linkInput} /><Text style={styles.unit}>فقد%</Text><TextInput value={link.latencyMs === null ? "" : String(link.latencyMs)} onChangeText={(value) => updateCustom((current) => ({ ...current, links: current.links.map((item) => item.id === link.id ? { ...item, latencyMs: Math.max(0, Number(value.replace(/[^0-9]/g, "")) || 0) } : item) }))} keyboardType="number-pad" style={styles.linkInput} /><Text style={styles.unit}>ms</Text><Pressable onPress={() => updateCustom((current) => ({ ...current, links: current.links.map((item) => item.id === link.id ? { ...item, enabled: !item.enabled } : item) }))} style={[styles.linkToggle, link.enabled ? styles.linkEnabled : styles.linkDisabled]}><Text style={styles.linkToggleText}>{link.enabled ? "نشط" : "مفصول"}</Text></Pressable></View></View>)}</View>
          <View style={styles.customControls}><Text style={styles.builderLabel}>TTL</Text><TextInput value={customTtlText} onChangeText={setCustomTtlText} keyboardType="number-pad" style={styles.ttlInput} placeholder="1–32" placeholderTextColor={palette.muted} /><Pressable onPress={runCustom} style={styles.customRun}><Text style={styles.customRunText}>تشغيل السيناريو</Text></Pressable><Pressable onPress={() => void saveCustom()} style={styles.saveButton}><Text style={styles.saveText}>حفظ</Text></Pressable></View>
          {customNotice && <Pressable onPress={() => setCustomNotice(null)}><Text style={styles.customNotice}>{customNotice}</Text></Pressable>}
          {customResult && <View style={[styles.customOutcome, customResult.delivered ? styles.resultSuccess : styles.resultFailure]}><Text style={styles.resultTitle}>{customResult.delivered ? "تم التسليم عبر MeshRouter" : "فشل تشغيل السيناريو"}</Text><Text style={styles.resultPath}>{customResult.error ?? `المسار: ${customResult.path.join(" → ") || "غير موجود"} · خطوات: ${customResult.steps}`}</Text>{customResult.events.slice(-5).map(({ nodeId, event }, index) => <Text key={`${event.id}-${index}`} style={styles.customEvent}>{nodeId}: {event.message}</Text>)}</View>}
        </View>
        <Text style={styles.footnote}>هذه محاكاة محلية للمنطق والمرور؛ لا تستخدم Bluetooth أو Wi‑Fi Direct الحقيقيين.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.background }, content: { padding: 20, paddingBottom: 32, gap: 14 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 2 }, title: { color: palette.text, fontSize: 25, fontWeight: "800" }, subtitle: { color: palette.muted, fontSize: 13, marginTop: 5 }, labBadge: { borderColor: palette.teal, borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 6 }, labBadgeText: { color: palette.teal, fontWeight: "800", fontSize: 12 },
  info: { backgroundColor: palette.panel, borderColor: palette.line, borderWidth: 1, borderRadius: 16, padding: 15 }, infoTitle: { color: palette.teal, fontSize: 15, fontWeight: "800", marginBottom: 5 }, infoText: { color: palette.muted, lineHeight: 20, fontSize: 13 }, sectionTitle: { color: palette.text, fontSize: 17, fontWeight: "800", marginTop: 5 }, scenarios: { gap: 9 }, scenario: { backgroundColor: palette.panel, borderColor: palette.line, borderWidth: 1, borderRadius: 13, padding: 13 }, scenarioSelected: { borderColor: palette.teal, backgroundColor: "#15343A" }, scenarioTitle: { color: palette.text, fontSize: 14, fontWeight: "700" }, scenarioText: { color: palette.muted, fontSize: 12, marginTop: 4, lineHeight: 18 },
  controls: { backgroundColor: palette.panel, borderRadius: 13, padding: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, control: { flexDirection: "row", alignItems: "center", gap: 10 }, controlLabel: { color: palette.text, fontSize: 13, fontWeight: "700" }, stepper: { flexDirection: "row", alignItems: "center", gap: 9 }, step: { width: 30, height: 30, borderRadius: 8, backgroundColor: palette.panelRaised, alignItems: "center", justifyContent: "center" }, stepText: { color: palette.teal, fontSize: 21 }, ttl: { color: palette.text, fontSize: 17, fontWeight: "800", minWidth: 18, textAlign: "center" }, toggleRow: { flexDirection: "row", alignItems: "center", gap: 8 }, toggle: { width: 38, height: 22, borderRadius: 12, backgroundColor: palette.line, padding: 3 }, toggleOn: { backgroundColor: palette.teal }, toggleDot: { height: 16, width: 16, borderRadius: 8, backgroundColor: palette.muted }, toggleDotOn: { backgroundColor: palette.background, alignSelf: "flex-end" }, runButton: { backgroundColor: palette.teal, borderRadius: 12, alignItems: "center", paddingVertical: 14 }, runButtonText: { color: palette.background, fontSize: 15, fontWeight: "800" },
  graphShell: { backgroundColor: "#101C27", borderRadius: 16, padding: 8, alignItems: "center" }, legend: { flexDirection: "row", gap: 18, paddingBottom: 5 }, legendText: { color: palette.muted, fontSize: 11 }, result: { borderRadius: 12, padding: 13, borderWidth: 1 }, resultSuccess: { backgroundColor: "#123832", borderColor: palette.teal }, resultFailure: { backgroundColor: "#3B252A", borderColor: palette.red }, resultIdle: { backgroundColor: palette.panel, borderColor: palette.line }, resultTitle: { color: palette.text, fontSize: 15, fontWeight: "800" }, resultPath: { color: palette.muted, marginTop: 5, fontSize: 13 }, log: { backgroundColor: palette.panel, borderRadius: 13, padding: 11, gap: 10 }, logRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 }, logIndex: { color: palette.amber, fontSize: 11, fontWeight: "800", width: 22 }, logText: { color: palette.text, fontSize: 12, flex: 1, lineHeight: 18 }, customHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8 }, customNote: { color: palette.muted, fontSize: 11, marginTop: 4 }, customBadge: { color: palette.amber, borderColor: palette.amber, borderWidth: 1, borderRadius: 8, paddingHorizontal: 7, paddingVertical: 4, fontSize: 10 }, customPanel: { backgroundColor: palette.panel, borderRadius: 14, padding: 13, gap: 10 }, label: { color: palette.muted, fontSize: 12, fontWeight: "700" }, nameInput: { color: palette.text, borderColor: palette.line, borderWidth: 1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8, fontSize: 13 }, builderToolbar: { flexDirection: "row", gap: 8 }, smallButton: { backgroundColor: palette.panelRaised, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8 }, smallButtonText: { color: palette.teal, fontSize: 12, fontWeight: "700" }, builderLabel: { color: palette.muted, fontSize: 12 }, nodeRows: { gap: 6 }, nodeRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopColor: palette.line, borderTopWidth: 1, paddingTop: 7 }, endpointRow: { flexDirection: "row", gap: 8 }, endpoint: { flex: 1, backgroundColor: palette.panelRaised, borderRadius: 8, padding: 8 }, endpointLabel: { color: palette.muted, fontSize: 10 }, endpointValue: { color: palette.teal, fontWeight: "800", marginTop: 3 }, pickerGroup: { gap: 5 }, pickerLabel: { color: palette.text, fontSize: 11 }, pickerRow: { flexDirection: "row", gap: 6, flexWrap: "wrap" }, nodeChoice: { minWidth: 32, borderRadius: 7, backgroundColor: palette.panelRaised, paddingHorizontal: 10, paddingVertical: 7, alignItems: "center" }, nodeChoiceSelected: { backgroundColor: "#15514C", borderColor: palette.teal, borderWidth: 1 }, nodeChoiceText: { color: palette.text, fontWeight: "800" }, linkPreview: { color: palette.amber, fontSize: 12, fontWeight: "700" }, addLinkButton: { backgroundColor: palette.panelRaised, borderRadius: 8, alignItems: "center", paddingVertical: 9 }, addLinkText: { color: palette.teal, fontSize: 12, fontWeight: "800" }, builderRows: { gap: 7 }, linkEditor: { borderTopColor: palette.line, borderTopWidth: 1, paddingTop: 8, gap: 7 }, builderRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, builderLink: { color: palette.text, fontSize: 13, fontWeight: "700" }, linkFields: { flexDirection: "row", alignItems: "center", gap: 4, flexWrap: "wrap" }, fieldButton: { backgroundColor: palette.panelRaised, borderRadius: 7, paddingHorizontal: 7, paddingVertical: 6 }, fieldText: { color: palette.blue, fontSize: 10, fontWeight: "700" }, linkInput: { width: 38, color: palette.text, borderColor: palette.line, borderWidth: 1, borderRadius: 6, paddingVertical: 5, textAlign: "center", fontSize: 11 }, unit: { color: palette.muted, fontSize: 9 }, linkToggle: { borderRadius: 7, paddingHorizontal: 8, paddingVertical: 5 }, linkEnabled: { backgroundColor: "#153F3C" }, linkDisabled: { backgroundColor: "#402A2F" }, linkToggleText: { color: palette.text, fontSize: 11 }, deleteButton: { backgroundColor: "#402A2F", borderRadius: 6, paddingHorizontal: 7, paddingVertical: 5 }, deleteText: { color: palette.red, fontSize: 10 }, customControls: { flexDirection: "row", alignItems: "center", gap: 8 }, ttlInput: { width: 50, color: palette.text, borderColor: palette.line, borderWidth: 1, borderRadius: 8, paddingVertical: 7, textAlign: "center" }, customRun: { flex: 1, backgroundColor: palette.teal, borderRadius: 9, alignItems: "center", paddingVertical: 10 }, customRunText: { color: palette.background, fontSize: 12, fontWeight: "800" }, saveButton: { backgroundColor: palette.panelRaised, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 10 }, saveText: { color: palette.teal, fontSize: 12, fontWeight: "800" }, customNotice: { color: palette.amber, fontSize: 12 }, customOutcome: { borderRadius: 10, borderWidth: 1, padding: 10, gap: 4 }, customEvent: { color: palette.text, fontSize: 11, lineHeight: 16 }, footnote: { color: palette.muted, fontSize: 11, textAlign: "center", marginTop: 4, lineHeight: 17 },
});
