import { useEffect, useRef, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { ScreenContainer } from "@/components/screen-container";
import { addMeshListener, sendMeshSecureData } from "@/modules/jesr-network/src";
import { assembleBase64File, MAX_FILE_BYTES, splitBase64File, type FileChunk } from "@/lib/mesh/file-transfer";

const colors = {
  background: "#0D1722",
  panel: "#142330",
  panelRaised: "#192B38",
  line: "#2A3D49",
  text: "#EAF1F4",
  muted: "#9AAAB3",
  teal: "#20C7B4",
  blue: "#76B7D8",
  red: "#E57676",
};
type IncomingFile = { name: string; mimeType: string; total: number; chunks: FileChunk[] };

function randomId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function safeName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80) || "received-file";
}

export default function FilesScreen() {
  const [targetId, setTargetId] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const incoming = useRef(new Map<string, IncomingFile>());

  async function saveReceivedFile(fileId: string, file: IncomingFile) {
    try {
      const assembled = assembleBase64File(file.chunks);
      if (!assembled) return;
      const base64 = assembled.base64;
      const destination = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ""}received-${safeName(file.name)}`;
      await FileSystem.writeAsStringAsync(destination, base64, { encoding: FileSystem.EncodingType.Base64 });
      incoming.current.delete(fileId);
      setNotice(`اكتمل استقبال الملف وحُفظ محلياً: ${destination}`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "تعذر حفظ الملف المستلم");
    }
  }

  useEffect(() => {
    const subscription = addMeshListener("onDataReceived", (event) => {
      if (event.dataType !== "file" || typeof event.data !== "string") return;
      try {
        const packet = JSON.parse(event.data) as FileChunk;
        if (!packet.fileId || packet.total < 1 || packet.total > 600 || packet.index < 0 || packet.index >= packet.total) return;
        const previous = incoming.current.get(packet.fileId) ?? {
          name: safeName(packet.name), mimeType: packet.mimeType, total: packet.total, chunks: [],
        };
        if (!previous.chunks.some((chunk) => chunk.index === packet.index)) previous.chunks.push(packet);
        incoming.current.set(packet.fileId, previous);
        if (previous.chunks.length !== previous.total) {
          setNotice(`استُقبل جزء ${packet.index + 1} من ${packet.total} للملف ${previous.name}`);
          return;
        }
        void saveReceivedFile(packet.fileId, previous);
      } catch {
        setNotice("وصل جزء ملف غير صالح وتم تجاهله.");
      }
    });
    return () => subscription.remove();
  }, []);

  async function chooseAndSend() {
    if (!targetId.trim()) {
      setNotice("أدخل معرّف الجهاز الهدف.");
      return;
    }
    setBusy(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: "*/*", copyToCacheDirectory: true });
      if (result.canceled || !result.assets?.[0]) return;
      const asset = result.assets[0];
      if (asset.size && asset.size > MAX_FILE_BYTES) throw new Error("الحد الحالي لنقل الملف هو 2MB.");
      const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 });
      if (base64.length > MAX_FILE_BYTES * 1.5) throw new Error("الملف أكبر من الحد الحالي بعد التحويل.");
      const fileId = randomId();
      const chunks = splitBase64File(fileId, asset.name, asset.mimeType ?? "application/octet-stream", base64);
      for (const chunk of chunks) {
        const packet = JSON.stringify(chunk);
        await sendMeshSecureData(targetId.trim(), "file", packet);
        setNotice(`إرسال الملف: ${chunk.index + 1}/${chunks.length}`);
      }
      setFileName(asset.name);
      setNotice(`اكتمل إرسال ${asset.name} في ${chunks.length} حزمة مشفرة.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "تعذر اختيار أو إرسال الملف");
    } finally {
      setBusy(false);
    }
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} safeAreaClassName="bg-[#0D1722]">
      <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>نقل محلي مشفر</Text>
            <Text style={styles.title}>الملفات</Text>
            <Text style={styles.subtitle}>تجزئة، تشفير، ثم إعادة تجميع على الوجهة</Text>
          </View>
          <View style={styles.badge}><Text style={styles.badgeText}>2MB</Text></View>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>بيانات الاتصال</Text>
          <TextInput value={targetId} onChangeText={setTargetId} placeholder="معرّف الجهاز الهدف" placeholderTextColor={colors.muted} autoCapitalize="none" style={styles.input} />
          <Text style={styles.help}>التشفير يُدار تلقائياً داخل التطبيق ولا يحتاج إلى مفتاح أو إعداد يدوي.</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>إرسال ملف</Text>
          {fileName && <Text style={styles.fileName}>آخر ملف: {fileName}</Text>}
          <Text style={styles.help}>تُرسل الملفات حالياً حتى 2MB على أجزاء متسلسلة. استكمال النقل بعد انقطاع الاتصال لم يُفعّل بعد.</Text>
          <Pressable disabled={busy} onPress={() => void chooseAndSend()} style={styles.primaryButton}><Text style={styles.primaryText}>{busy ? "جارٍ الإرسال…" : "اختيار وإرسال ملف"}</Text></Pressable>
        </View>
        {notice && <Text style={styles.notice}>{notice}</Text>}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: colors.background },
  content: { padding: 20, gap: 16, paddingBottom: 36 },
  header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  kicker: { color: colors.teal, fontSize: 12, fontWeight: "700", textAlign: "right" },
  title: { color: colors.text, fontSize: 28, fontWeight: "800", textAlign: "right", marginTop: 4 },
  subtitle: { color: colors.muted, fontSize: 13, textAlign: "right", marginTop: 4 },
  badge: { borderWidth: 1, borderColor: colors.teal, borderRadius: 14, paddingHorizontal: 11, paddingVertical: 7 },
  badgeText: { color: colors.teal, fontSize: 11, fontWeight: "800" },
  card: { backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 16, gap: 10 },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: "800", textAlign: "right" },
  input: { backgroundColor: colors.panelRaised, borderWidth: 1, borderColor: colors.line, borderRadius: 12, color: colors.text, paddingHorizontal: 13, paddingVertical: 12, textAlign: "right", fontSize: 14 },
  help: { color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "right" },
  primaryButton: { backgroundColor: colors.teal, borderRadius: 12, alignItems: "center", paddingVertical: 13 },
  primaryText: { color: "#06211F", fontSize: 14, fontWeight: "800" },
  fileName: { color: colors.blue, fontSize: 13, textAlign: "right" },
  notice: { color: colors.blue, fontSize: 13, lineHeight: 19, textAlign: "right", paddingHorizontal: 4 },
});
