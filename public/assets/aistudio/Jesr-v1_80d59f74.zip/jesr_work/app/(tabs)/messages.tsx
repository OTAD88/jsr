import { useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Animated, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { addMeshListener, getMeshSnapshot, sendMeshSecureData, type JesrPeer } from "@/modules/jesr-network/src";

const palette = {
  ink: "#050A13",
  navy: "#091525",
  panel: "#101E31",
  panelRaised: "#172A40",
  line: "#28425A",
  text: "#F3F8FF",
  muted: "#8DA4B8",
  cyan: "#6BE7F2",
  violet: "#9C8CFF",
  green: "#6FF0B0",
  red: "#FF8296",
};
const FRIENDS_KEY = "jesr.friends.v1";
const PROFILE_KEY = "jesr.profile.v1";

type Friend = { id: string; name: string };
type ChatMessage = { id: string; at: number; from: string; text: string; incoming: boolean };

export default function MessagesScreen() {
  const [profileName, setProfileName] = useState("جهاز جسر");
  const [profileId, setProfileId] = useState("غير متاح");
  const [profileDraft, setProfileDraft] = useState("");
  const [friends, setFriends] = useState<Friend[]>([]);
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [friendName, setFriendName] = useState("");
  const [friendId, setFriendId] = useState("");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [delivery, setDelivery] = useState<"idle" | "sending" | "sent" | "failed">("idle");
  const [connectedPeers, setConnectedPeers] = useState<JesrPeer[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [pulse] = useState(() => new Animated.Value(0.35));

  useEffect(() => {
    void Promise.all([AsyncStorage.getItem(PROFILE_KEY), AsyncStorage.getItem(FRIENDS_KEY), getMeshSnapshot()]).then(([profile, saved, snapshot]) => {
      if (profile) {
        setProfileName(profile);
        setProfileDraft(profile);
      }
      setProfileId(snapshot.localId);
      setConnectedPeers(snapshot.peers.filter((peer) => peer.connected));
      if (saved) setFriends(JSON.parse(saved) as Friend[]);
    }).catch(() => setNotice("تعذر استعادة الحسابات المحلية."));
    const stateSub = addMeshListener("onMeshState", (snapshot) => {
      setProfileId(snapshot.localId);
      setConnectedPeers(snapshot.peers.filter((peer) => peer.connected));
    });
    const dataSub = addMeshListener("onDataReceived", (event) => {
      if (event.dataType !== "message" || typeof event.data !== "string") return;
      setMessages((current) => current.some((message) => message.id === event.id) ? current : [...current, {
        id: event.id,
        at: event.at,
        from: event.nodeId ?? selectedFriend?.name ?? "جهاز بعيد",
        text: event.data,
        incoming: true,
      }]);
      setNotice("وصلت رسالة جديدة.");
    });
    const logSub = addMeshListener("onMeshLog", (event) => {
      if (event.kind === "routing_failed" || event.kind === "data_decrypt_failed") {
        setDelivery("failed");
        setNotice(event.message);
      }
      if (event.kind === "data_received") setDelivery("sent");
    });
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 0.9, duration: 1500, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0.35, duration: 1500, useNativeDriver: true }),
    ]));
    loop.start();
    return () => { stateSub.remove(); dataSub.remove(); logSub.remove(); loop.stop(); };
  }, [pulse, selectedFriend?.name]);

  const orderedMessages = useMemo(() => [...messages].sort((a, b) => a.at - b.at), [messages]);

  async function saveFriends(next: Friend[]) {
    setFriends(next);
    await AsyncStorage.setItem(FRIENDS_KEY, JSON.stringify(next));
  }
  async function saveProfile() {
    const next = profileDraft.trim();
    if (!next) return;
    setProfileName(next);
    await AsyncStorage.setItem(PROFILE_KEY, next);
    setNotice("تم حفظ اسم حسابك محلياً.");
  }
  async function addFriend() {
    const id = friendId.trim();
    const name = friendName.trim() || "صديق جديد";
    if (!id || id === profileId) {
      setNotice("أدخل معرّف حساب الطرف الآخر، وليس معرّف جهازك.");
      return;
    }
    const next = [...friends.filter((friend) => friend.id !== id), { id, name }];
    await saveFriends(next);
    setSelectedFriend({ id, name });
    setFriendId("");
    setFriendName("");
    setShowAdd(false);
    setNotice("تمت إضافة الحساب إلى أصدقائك.");
  }
  async function sendMessage() {
    if (!selectedFriend) { setNotice("أضف أو اختر صديقاً أولاً."); return; }
    const text = draft.trim();
    if (!text) { setNotice("اكتب رسالة أولاً."); return; }
    setDelivery("sending");
    setNotice("جارٍ تسليم الرسالة عبر أقرب مسار…");
    try {
      const packetId = await sendMeshSecureData(selectedFriend.id, "message", text);
      setMessages((current) => [...current, { id: packetId, at: Date.now(), from: profileName, text, incoming: false }]);
      setDraft("");
      setDelivery("sent");
      setNotice("تم تسليم الحزمة إلى محرك الشبكة؛ سيظهر الفشل فوراً إن انقطع المسار.");
    } catch (error) {
      setDelivery("failed");
      setNotice(error instanceof Error ? error.message : "تعذر إرسال الرسالة");
    }
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} safeAreaClassName="bg-[#050A13]">
      <ScrollView style={styles.page} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View><Text style={styles.eyebrow}>JESR / PRIVATE MESH</Text><Text style={styles.title}>غرفة الاتصال</Text><Text style={styles.subtitle}>أضف حساباً، اختره، وتحدث. الباقي تلقائي.</Text></View>
          <Animated.View style={[styles.signal, { opacity: pulse }]}><Text style={styles.signalText}>{connectedPeers.length} متصل</Text></Animated.View>
        </View>

        <View style={styles.hero}>
          <View style={styles.heroGlow} /><Text style={styles.heroOverline}>هوية الحساب</Text>
          <Text style={styles.profileName}>{profileName}</Text>
          <Text selectable style={styles.profileId}>{profileId}</Text>
          <View style={styles.profileEdit}><TextInput value={profileDraft} onChangeText={setProfileDraft} placeholder="اسمك الظاهر" placeholderTextColor={palette.muted} style={styles.compactInput} accessibilityLabel="اسم حسابك" /><Pressable onPress={() => void saveProfile()} accessibilityRole="button" style={({ pressed }) => [styles.ghostButton, pressed && styles.pressed]}><Text style={styles.ghostText}>حفظ</Text></Pressable></View>
        </View>

        <View style={styles.sectionHead}><Text style={styles.sectionTitle}>أصدقاؤك</Text><Pressable onPress={() => setShowAdd((value) => !value)} accessibilityRole="button" accessibilityLabel="إضافة حساب أو صديق" style={({ pressed }) => [styles.addButton, pressed && styles.pressed]}><Text style={styles.addText}>{showAdd ? "إغلاق" : "+ إضافة حساب"}</Text></Pressable></View>
        {showAdd && <View style={styles.addPanel}><TextInput value={friendName} onChangeText={setFriendName} placeholder="اسم الصديق" placeholderTextColor={palette.muted} style={styles.input} accessibilityLabel="اسم الصديق" /><TextInput value={friendId} onChangeText={setFriendId} placeholder="معرّف حساب الصديق" placeholderTextColor={palette.muted} autoCapitalize="none" style={styles.input} accessibilityLabel="معرّف حساب الصديق" /><Pressable onPress={() => void addFriend()} accessibilityRole="button" style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}><Text style={styles.primaryText}>إضافة إلى الحسابات</Text></Pressable></View>}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.friendRow}>
          {friends.length === 0 ? <Text style={styles.empty}>لا يوجد أصدقاء بعد. أضف معرّف الحساب الآخر مرة واحدة.</Text> : friends.map((friend) => <Pressable key={friend.id} onPress={() => setSelectedFriend(friend)} accessibilityRole="button" accessibilityState={{ selected: selectedFriend?.id === friend.id }} style={({ pressed }) => [styles.friendChip, selectedFriend?.id === friend.id && styles.friendChipActive, pressed && styles.pressed]}><View style={styles.avatar}><Text style={styles.avatarText}>{friend.name.slice(0, 1)}</Text></View><View><Text style={styles.friendName}>{friend.name}</Text><Text style={styles.friendId}>{friend.id.slice(0, 12)}…</Text></View></Pressable>)}
        </ScrollView>

        <View style={styles.chatCard}><View style={styles.chatHeader}><View><Text style={styles.sectionTitle}>{selectedFriend?.name ?? "اختر محادثة"}</Text><Text style={styles.chatStatus}>{selectedFriend ? (connectedPeers.some((peer) => peer.id === selectedFriend.id) ? "متصل الآن" : "سيُعاد التوجيه عند ظهوره") : "أضف حساباً للبدء"}</Text></View><Text style={[styles.delivery, delivery === "failed" && styles.deliveryFailed]}>{delivery === "sending" ? "جارٍ…" : delivery === "failed" ? "فشل" : delivery === "sent" ? "مشفر" : "AES-GCM"}</Text></View><View style={styles.messages}>{orderedMessages.length === 0 ? <Text style={styles.empty}>ستظهر رسائلك هنا بشكل سينمائي وهادئ.</Text> : orderedMessages.map((message) => <View key={message.id} style={[styles.bubble, message.incoming ? styles.incoming : styles.outgoing]}><Text style={styles.meta}>{message.incoming ? `من ${message.from}` : "أنت"}</Text><Text style={styles.messageText}>{message.text}</Text></View>)}</View><View style={styles.composer}><TextInput value={draft} onChangeText={setDraft} placeholder={selectedFriend ? "اكتب رسالة…" : "اختر صديقاً أولاً"} placeholderTextColor={palette.muted} editable={Boolean(selectedFriend)} multiline style={styles.messageInput} accessibilityLabel="نص الرسالة" /><Pressable onPress={() => void sendMessage()} disabled={!selectedFriend || delivery === "sending"} accessibilityRole="button" accessibilityLabel="إرسال الرسالة" style={({ pressed }) => [styles.sendButton, pressed && styles.pressed, (!selectedFriend || delivery === "sending") && styles.disabled]}><Text style={styles.sendText}>إرسال</Text></Pressable></View></View>
        {notice && <Pressable onPress={() => setNotice(null)} accessibilityRole="alert" style={styles.notice}><Text style={styles.noticeText}>{notice}</Text></Pressable>}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: palette.ink }, content: { padding: 18, gap: 15, paddingBottom: 38 }, header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }, eyebrow: { color: palette.cyan, fontSize: 10, fontWeight: "900", letterSpacing: 1.5, textAlign: "right" }, title: { color: palette.text, fontSize: 31, fontWeight: "900", textAlign: "right", marginTop: 5 }, subtitle: { color: palette.muted, fontSize: 12, textAlign: "right", marginTop: 5 }, signal: { borderWidth: 1, borderColor: "#27655F", backgroundColor: "#0B2B32", paddingHorizontal: 10, paddingVertical: 8, borderRadius: 20 }, signalText: { color: palette.green, fontSize: 11, fontWeight: "800" }, hero: { backgroundColor: palette.navy, borderRadius: 25, borderWidth: 1, borderColor: palette.line, padding: 20, overflow: "hidden" }, heroGlow: { position: "absolute", width: 180, height: 180, borderRadius: 90, backgroundColor: "#263D83", opacity: 0.22, right: -55, top: -75 }, heroOverline: { color: palette.violet, fontSize: 11, fontWeight: "800", textAlign: "right" }, profileName: { color: palette.text, fontSize: 25, fontWeight: "900", textAlign: "right", marginTop: 6 }, profileId: { color: palette.muted, fontSize: 11, textAlign: "right", marginTop: 4 }, profileEdit: { flexDirection: "row-reverse", gap: 8, marginTop: 16 }, compactInput: { flex: 1, color: palette.text, backgroundColor: palette.panelRaised, borderRadius: 12, paddingHorizontal: 12, textAlign: "right", minHeight: 44 }, ghostButton: { minWidth: 66, borderRadius: 12, borderWidth: 1, borderColor: palette.violet, justifyContent: "center", alignItems: "center" }, ghostText: { color: palette.violet, fontWeight: "800" }, sectionHead: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }, sectionTitle: { color: palette.text, fontSize: 16, fontWeight: "900", textAlign: "right" }, addButton: { minHeight: 38, borderRadius: 12, backgroundColor: "#17294B", paddingHorizontal: 13, justifyContent: "center" }, addText: { color: palette.cyan, fontSize: 12, fontWeight: "900" }, addPanel: { backgroundColor: palette.panel, borderRadius: 18, borderWidth: 1, borderColor: palette.line, padding: 14, gap: 9 }, input: { minHeight: 46, backgroundColor: palette.panelRaised, borderRadius: 12, color: palette.text, paddingHorizontal: 13, textAlign: "right" }, primaryButton: { minHeight: 46, borderRadius: 13, backgroundColor: palette.violet, alignItems: "center", justifyContent: "center" }, primaryText: { color: "#0A0A18", fontWeight: "900" }, friendRow: { gap: 10, paddingVertical: 2 }, friendChip: { flexDirection: "row-reverse", alignItems: "center", gap: 9, backgroundColor: palette.panel, borderWidth: 1, borderColor: palette.line, borderRadius: 16, padding: 9, minWidth: 150 }, friendChipActive: { borderColor: palette.cyan, backgroundColor: "#112D42" }, avatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#263C78", alignItems: "center", justifyContent: "center" }, avatarText: { color: palette.text, fontSize: 16, fontWeight: "900" }, friendName: { color: palette.text, fontSize: 12, fontWeight: "800", textAlign: "right" }, friendId: { color: palette.muted, fontSize: 9, marginTop: 2 }, chatCard: { backgroundColor: palette.panel, borderRadius: 24, borderWidth: 1, borderColor: palette.line, padding: 14 }, chatHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: palette.line }, chatStatus: { color: palette.muted, fontSize: 10, textAlign: "right", marginTop: 3 }, delivery: { color: palette.green, fontSize: 10, fontWeight: "900" }, deliveryFailed: { color: palette.red }, messages: { minHeight: 210, paddingVertical: 12, gap: 9, justifyContent: "flex-end" }, empty: { color: palette.muted, textAlign: "right", fontSize: 12, lineHeight: 19 }, bubble: { maxWidth: "87%", borderRadius: 17, padding: 11, gap: 4 }, incoming: { alignSelf: "flex-start", backgroundColor: palette.panelRaised, borderBottomLeftRadius: 4 }, outgoing: { alignSelf: "flex-end", backgroundColor: "#29317A", borderBottomRightRadius: 4 }, meta: { color: palette.muted, fontSize: 10, textAlign: "right" }, messageText: { color: palette.text, fontSize: 15, lineHeight: 21, textAlign: "right" }, composer: { flexDirection: "row-reverse", gap: 8, alignItems: "flex-end", borderTopWidth: 1, borderTopColor: palette.line, paddingTop: 12 }, messageInput: { flex: 1, minHeight: 46, maxHeight: 110, color: palette.text, backgroundColor: palette.panelRaised, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 12, textAlign: "right", textAlignVertical: "top" }, sendButton: { minHeight: 46, minWidth: 70, borderRadius: 14, backgroundColor: palette.cyan, alignItems: "center", justifyContent: "center" }, sendText: { color: palette.ink, fontWeight: "900" }, notice: { backgroundColor: "#241D42", borderWidth: 1, borderColor: "#594CA0", borderRadius: 14, padding: 12 }, noticeText: { color: palette.text, fontSize: 12, lineHeight: 18, textAlign: "right" }, pressed: { opacity: 0.7, transform: [{ scale: 0.98 }] }, disabled: { opacity: 0.42 },
});
