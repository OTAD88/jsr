import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import {
  addMeshListener,
  getMeshSnapshot,
  isJesrNativeAvailable,
  sendMeshSecureData,
  type JesrLogEvent,
} from "@/modules/jesr-network/src";
import {
  loadChatStore,
  makeLocalMessageId,
  updateChatStore,
  upsertMessage,
  type ChatMessage,
  type ChatStore,
} from "@/lib/mesh/chat-store";

const C = {
  background: "#091511",
  backgroundSoft: "#0D1C16",
  surface: "#12241C",
  surfaceRaised: "#192D24",
  surfaceMuted: "#20372D",
  line: "#294137",
  accent: "#75AE9D",
  accentBright: "#A4D1BF",
  accentDark: "#365B4E",
  text: "#F1F5F0",
  muted: "#A0B3A9",
  subtle: "#71857B",
  warning: "#D8B77A",
  danger: "#D98A82",
};

function formatTime(at: number) {
  return new Date(at).toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
}

function parseIncoming(raw: string, packetId: string | undefined, peerId: string): ChatMessage | null {
  try {
    const value = JSON.parse(raw) as { messageId?: unknown; text?: unknown; createdAt?: unknown };
    if (typeof value.text === "string" && value.text.length > 0) {
      return {
        id: typeof value.messageId === "string" ? value.messageId : packetId || makeLocalMessageId(),
        packetId,
        peerId,
        text: value.text,
        at: typeof value.createdAt === "number" ? value.createdAt : Date.now(),
        direction: "incoming",
        status: "delivered",
      };
    }
  } catch {
    // Older versions sent the message body as plain text.
  }
  if (!raw) return null;
  return { id: packetId || makeLocalMessageId(), packetId, peerId, text: raw, at: Date.now(), direction: "incoming", status: "delivered" };
}

function Bubble({ message, onRetry }: { message: ChatMessage; onRetry: () => void }) {
  const outgoing = message.direction === "outgoing";
  return (
    <View style={[styles.messageLine, outgoing ? styles.messageLineOut : styles.messageLineIn]}>
      <View style={[styles.bubble, outgoing ? styles.bubbleOut : styles.bubbleIn]}>
        <Text style={[styles.messageText, outgoing ? styles.messageTextOut : styles.messageTextIn]}>{message.text}</Text>
        <View style={styles.messageMeta}>
          <Text style={[styles.messageTime, outgoing ? styles.messageTimeOut : styles.messageTimeIn]}>{formatTime(message.at)}</Text>
          {outgoing ? (
            message.status === "delivered" ? <Feather name="check-circle" size={12} color={C.accentBright} /> :
            message.status === "failed" ? <Pressable onPress={onRetry} hitSlop={7} style={styles.retryInline}><Feather name="refresh-cw" size={11} color={C.warning} /><Text style={styles.retryInlineText}>إعادة</Text></Pressable> :
            <Feather name="clock" size={12} color="rgba(9,21,17,0.62)" />
          ) : null}
        </View>
      </View>
    </View>
  );
}

export default function ChatScreen() {
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  const peerId = Array.isArray(params.id) ? params.id[0] : params.id ?? "";
  const router = useRouter();
  const [store, setStore] = useState<ChatStore>({ displayName: "مستخدم جسر", friends: [], requests: [], pendingControls: [], messages: [] });
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState("");
  const [connected, setConnected] = useState(false);
  const [inputHeight, setInputHeight] = useState(42);
  const storeRef = useRef<ChatStore | null>(null);
  const earlyAcks = useRef(new Set<string>());
  const retrying = useRef(false);
  const wasNetworkActive = useRef(false);
  const listRef = useRef<FlatList<ChatMessage>>(null);
  const sendScale = useRef(new Animated.Value(1)).current;

  const commit = useCallback(async (mutator: (current: ChatStore) => ChatStore) => {
    const next = await updateChatStore(mutator);
    storeRef.current = next;
    setStore(next);
    return next;
  }, []);

  const friend = useMemo(() => store.friends.find((item) => item.id === peerId), [store.friends, peerId]);
  const messages = useMemo(
    () => store.messages.filter((message) => message.peerId === peerId).sort((a, b) => a.at - b.at),
    [store.messages, peerId],
  );

  const transmit = useCallback(async (message: ChatMessage) => {
    if (!isJesrNativeAvailable || !peerId) return;
    try {
      const body = JSON.stringify({ messageId: message.id, text: message.text, createdAt: message.at });
      const packetId = await sendMeshSecureData(peerId, "message", body);
      const wasAckedEarly = earlyAcks.current.has(packetId);
      if (wasAckedEarly) earlyAcks.current.delete(packetId);
      await commit((current) => ({
        ...current,
        messages: current.messages.map((item) => item.id === message.id && item.peerId === peerId
          ? { ...item, packetId, status: wasAckedEarly ? "delivered" : "sending" }
          : item),
      }));
    } catch {
      await commit((current) => ({
        ...current,
        messages: current.messages.map((item) => item.id === message.id && item.peerId === peerId
          ? { ...item, status: "queued" }
          : item),
      }));
      setNotice("حُفظت الرسالة على هذا الجهاز وستُحاول جسر إرسالها عند توفر الاتصال.");
    }
  }, [commit, peerId]);

  const retryPending = useCallback(async (source?: ChatStore) => {
    if (retrying.current || !peerId || !isJesrNativeAvailable) return;
    const current = source ?? storeRef.current;
    if (!current) return;
    const pending = current.messages.filter((message) => message.peerId === peerId && message.direction === "outgoing" && message.status === "queued");
    if (!pending.length) return;
    retrying.current = true;
    try {
      for (const message of pending) await transmit({ ...message, status: "queued", packetId: undefined });
    } finally {
      retrying.current = false;
    }
  }, [peerId, transmit]);

  useEffect(() => {
    let active = true;
    void (async () => {
      const initial = await loadChatStore();
      if (!active) return;
      const recovered = {
        ...initial,
        messages: initial.messages.map((item) => item.direction === "outgoing" && item.status === "sending"
          ? { ...item, status: "queued" as const, packetId: undefined }
          : item),
      };
      storeRef.current = recovered;
      setStore(recovered);
      if (recovered !== initial) await updateChatStore(() => recovered);
      setLoading(false);
      try {
        const snapshot = await getMeshSnapshot();
        wasNetworkActive.current = snapshot.active;
        setConnected(snapshot.peers.some((peer) => peer.id === peerId && peer.connected) || snapshot.routes.some((route) => route.destinationId === peerId));
        if (snapshot.active) void retryPending(recovered);
      } catch { /* connection is retried when the native network becomes active */ }
    })();

    const dataSub = addMeshListener("onDataReceived", (event) => {
      if (!event.nodeId || typeof event.data !== "string") return;
      if (event.dataType === "friend_accept" || event.dataType === "friend_reject") {
        void loadChatStore().then((next) => { storeRef.current = next; setStore(next); });
        return;
      }
      if (event.dataType !== "message") return;
      void loadChatStore().then((saved) => {
        if (!saved.friends.some((item) => item.id === event.nodeId && item.status === "accepted")) return;
        const incoming = parseIncoming(event.data, event.packetId, event.nodeId!);
        if (!incoming) return;
        void commit((current) => ({
          ...current,
          messages: upsertMessage(current.messages, incoming),
        }));
      });
    });

    const logSub = addMeshListener("onMeshLog", (event: JesrLogEvent) => {
      const packetId = event.packetId;
      if (!packetId) return;
      if (event.kind === "data_delivered") {
        const alreadyTracked = storeRef.current?.messages.some((item) => item.packetId === packetId) ?? false;
        if (!alreadyTracked) earlyAcks.current.add(packetId);
        void commit((current) => ({
          ...current,
          messages: current.messages.map((item) => item.packetId === packetId ? { ...item, status: "delivered" } : item),
        }));
      } else if (event.kind === "data_delivery_failed") {
        void commit((current) => ({
          ...current,
          messages: current.messages.map((item) => item.packetId === packetId ? { ...item, status: "failed" } : item),
        }));
      }
    });

    const stateSub = addMeshListener("onMeshState", (snapshot) => {
      setConnected(snapshot.peers.some((peer) => peer.id === peerId && peer.connected) || snapshot.routes.some((route) => route.destinationId === peerId));
      const becameActive = snapshot.active && !wasNetworkActive.current;
      wasNetworkActive.current = snapshot.active;
      if (becameActive) void retryPending();
    });

    return () => { active = false; dataSub.remove(); logSub.remove(); stateSub.remove(); };
  }, [commit, peerId, retryPending]);

  useEffect(() => {
    if (messages.length > 0) {
      const timer = setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);
      return () => clearTimeout(timer);
    }
  }, [messages.length]);

  async function sendMessage() {
    const text = draft.trim();
    if (!text || sending || !peerId) return;
    if (friend?.status !== "accepted") {
      setNotice("لن تتمكن من المراسلة حتى يقبل الطرف الآخر طلب الصداقة.");
      return;
    }
    const message: ChatMessage = {
      id: makeLocalMessageId(),
      peerId,
      text,
      at: Date.now(),
      direction: "outgoing",
      status: "queued",
    };
    setSending(true);
    setDraft("");
    await commit((current) => ({ ...current, messages: upsertMessage(current.messages, message) }));
    await transmit(message);
    setSending(false);
  }

  const retryMessage = useCallback((message: ChatMessage) => {
    void commit((current) => ({
      ...current,
      messages: current.messages.map((item) => item.id === message.id ? { ...item, status: "queued", packetId: undefined } : item),
    })).then((next) => {
      const pending = next.messages.find((item) => item.id === message.id && item.peerId === peerId);
      if (pending) void transmit(pending);
    });
  }, [commit, peerId, transmit]);

  const headerName = friend?.name ?? "جهة اتصال";
  const friendshipPending = friend?.status !== "accepted";

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} safeAreaClassName="bg-[#091511]">
      <KeyboardAvoidingView style={styles.page} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={4}>
        <View style={styles.header}>
          <View style={styles.headerIdentity}>
            <View style={styles.avatar}><Text style={styles.avatarText}>{headerName.trim().slice(0, 1) || "ج"}</Text></View>
            <View style={styles.headerText}>
              <Text style={styles.headerName} numberOfLines={1}>{headerName}</Text>
              <View style={styles.presenceRow}><View style={[styles.presenceDot, connected && styles.presenceDotOn]} /><Text style={styles.headerStatus}>{friendshipPending ? "بانتظار قبول طلب الصداقة" : connected ? "متاح الآن" : "سيصل عند توفر الاتصال"}</Text></View>
            </View>
          </View>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="رجوع">
            <Feather name="arrow-right" size={19} color={C.text} />
          </Pressable>
        </View>

        <View style={styles.chatBackdrop}>
          <View style={styles.backdropOrb} />
          <View style={styles.conversationIntro}>
            <View style={styles.introRule} />
            <Text style={styles.introTitle}>بداية المحادثة</Text>
            <Text style={styles.introSubtitle}>تظهر الرسائل هنا وتُحفظ على جهازك.</Text>
          </View>
          {loading ? (
            <View style={styles.loading}><ActivityIndicator color={C.accent} /></View>
          ) : messages.length === 0 ? (
            <View style={styles.emptyMessages}>
              <View style={styles.emptyMessageIcon}><Feather name="message-circle" size={23} color={C.accentBright} /></View>
              <Text style={styles.emptyMessageTitle}>قل مرحباً</Text>
              <Text style={styles.emptyMessageText}>أرسل أول رسالة إلى {headerName}.</Text>
            </View>
          ) : (
            <FlatList
              ref={listRef}
              data={messages}
              keyExtractor={(item) => `${item.peerId}:${item.id}`}
              contentContainerStyle={styles.messagesContent}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => <Bubble message={item} onRetry={() => retryMessage(item)} />}
            />
          )}
          {notice ? <Pressable onPress={() => setNotice("")} style={styles.notice}><Feather name="info" size={14} color={C.accentBright} /><Text style={styles.noticeText}>{notice}</Text><Feather name="x" size={13} color={C.subtle} /></Pressable> : null}
        </View>

        <View style={styles.composerWrap}>
          <View style={styles.composer}>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder={friendshipPending ? "بانتظار قبول طلب الصداقة" : "اكتب رسالة…"}
              placeholderTextColor={C.subtle}
              editable={!friendshipPending}
              style={[styles.input, { height: Math.max(42, Math.min(112, inputHeight)) }]}
              multiline
              maxLength={1500}
              textAlign="right"
              textAlignVertical="center"
              onContentSizeChange={(event) => setInputHeight(event.nativeEvent.contentSize.height + 13)}
              accessibilityLabel="نص الرسالة"
            />
            <Animated.View style={{ transform: [{ scale: sendScale }] }}>
              <Pressable
                onPress={() => void sendMessage()}
                onPressIn={() => Animated.spring(sendScale, { toValue: 0.9, useNativeDriver: true, speed: 30 }).start()}
                onPressOut={() => Animated.spring(sendScale, { toValue: 1, useNativeDriver: true, speed: 24 }).start()}
                disabled={!draft.trim() || sending || friendshipPending}
                style={[styles.sendButton, (!draft.trim() || sending) && styles.sendButtonDisabled]}
                accessibilityRole="button"
                accessibilityLabel="إرسال"
              >
                {sending ? <ActivityIndicator size="small" color={C.background} /> : <Feather name="arrow-up" size={21} color={C.background} />}
              </Pressable>
            </Animated.View>
          </View>
          <Text style={styles.composerHint}>{friendshipPending ? "ستتاح المحادثة بعد قبول طلب الصداقة" : "تُحفظ الرسائل محلياً حتى عند انقطاع الاتصال"}</Text>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  header: { minHeight: 70, paddingHorizontal: 17, paddingVertical: 10, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", backgroundColor: C.background, borderBottomWidth: 1, borderBottomColor: "rgba(117,174,157,0.13)" },
  headerIdentity: { flexDirection: "row-reverse", alignItems: "center", gap: 11, flex: 1 },
  avatar: { width: 43, height: 43, borderRadius: 15, backgroundColor: C.surfaceMuted, borderWidth: 1, borderColor: C.accentDark, alignItems: "center", justifyContent: "center" },
  avatarText: { color: C.accentBright, fontSize: 17, fontWeight: "800" },
  headerText: { flex: 1, alignItems: "flex-start" },
  headerName: { color: C.text, fontSize: 15, fontWeight: "800", textAlign: "right" },
  presenceRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 4 },
  presenceDot: { width: 6, height: 6, borderRadius: 4, backgroundColor: C.subtle },
  presenceDotOn: { backgroundColor: C.accent },
  headerStatus: { color: C.subtle, fontSize: 10 },
  backButton: { width: 39, height: 39, borderRadius: 13, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, alignItems: "center", justifyContent: "center" },
  chatBackdrop: { flex: 1, overflow: "hidden", backgroundColor: C.backgroundSoft },
  backdropOrb: { position: "absolute", width: 240, height: 240, borderRadius: 130, backgroundColor: C.accentDark, opacity: 0.12, top: -155, left: -95 },
  conversationIntro: { alignItems: "center", paddingTop: 17, paddingBottom: 11 },
  introRule: { width: 22, height: 2, borderRadius: 3, backgroundColor: C.accent, marginBottom: 8 },
  introTitle: { color: C.accentBright, fontSize: 10, fontWeight: "700" },
  introSubtitle: { color: C.subtle, fontSize: 9, marginTop: 4 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  emptyMessages: { flex: 1, alignItems: "center", justifyContent: "center", paddingBottom: 50 },
  emptyMessageIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line, alignItems: "center", justifyContent: "center", marginBottom: 13 },
  emptyMessageTitle: { color: C.text, fontSize: 16, fontWeight: "800" },
  emptyMessageText: { color: C.subtle, fontSize: 11, marginTop: 5 },
  messagesContent: { paddingHorizontal: 14, paddingTop: 10, paddingBottom: 18, gap: 7 },
  messageLine: { width: "100%", flexDirection: "row", marginVertical: 2 },
  messageLineIn: { justifyContent: "flex-start" },
  messageLineOut: { justifyContent: "flex-end" },
  bubble: { maxWidth: "84%", minWidth: 80, paddingHorizontal: 13, paddingTop: 10, paddingBottom: 7, borderRadius: 18, borderWidth: 1 },
  bubbleIn: { backgroundColor: C.surface, borderColor: C.line, borderBottomLeftRadius: 5 },
  bubbleOut: { backgroundColor: C.accent, borderColor: "rgba(164,209,191,0.55)", borderBottomRightRadius: 5 },
  messageText: { fontSize: 14, lineHeight: 21, textAlign: "right" },
  messageTextIn: { color: C.text },
  messageTextOut: { color: C.background },
  messageMeta: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 5, marginTop: 5 },
  messageTime: { fontSize: 9 },
  messageTimeIn: { color: C.subtle },
  messageTimeOut: { color: "rgba(9,21,17,0.62)" },
  retryInline: { flexDirection: "row", alignItems: "center", gap: 3 },
  retryInlineText: { color: C.warning, fontSize: 9, fontWeight: "700" },
  notice: { marginHorizontal: 13, marginBottom: 8, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 9, flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line },
  noticeText: { color: C.muted, fontSize: 10, flex: 1, lineHeight: 15, textAlign: "right" },
  composerWrap: { paddingHorizontal: 13, paddingTop: 10, paddingBottom: 6, backgroundColor: C.background, borderTopWidth: 1, borderTopColor: "rgba(117,174,157,0.16)" },
  composer: { minHeight: 54, flexDirection: "row-reverse", alignItems: "flex-end", gap: 9, padding: 6, borderRadius: 18, backgroundColor: C.surface, borderWidth: 1, borderColor: C.line },
  input: { flex: 1, minHeight: 42, maxHeight: 112, color: C.text, paddingHorizontal: 10, paddingVertical: 9, fontSize: 13, textAlign: "right" },
  sendButton: { width: 41, height: 41, borderRadius: 14, backgroundColor: C.accent, alignItems: "center", justifyContent: "center" },
  sendButtonDisabled: { opacity: 0.48 },
  composerHint: { color: C.subtle, fontSize: 9, textAlign: "center", paddingTop: 7, paddingBottom: 2 },
  pressed: { opacity: 0.8 },
});
